// src/app/admin/all-documents/page.tsx
import DocumentListPage from "@/components/document-list-page";
import { requireUserType } from "@/lib/auth/guards";
import { USER_TYPE } from "@/lib/auth/roles";
import { getDocumentsForAdmin } from "@/lib/document-queries";

export const dynamic = "force-dynamic";

export default async function AdminAllDocumentsPage({ searchParams }: any) {
  const session = await requireUserType([USER_TYPE.ADMIN]);
  const data = await getDocumentsForAdmin();

  return (
    <DocumentListPage
      session={session}
      rows={data.documents}
      searchParams={await Promise.resolve(searchParams)}
      title="All Documents"
      subtitle="Every document in the system"
      emptyMessage="No documents available."
      showDownloadFilters
      table={{ showBulkActions: true, allowAdminDelete: true, showDownloadTracking: true }}
    />
  );
}
