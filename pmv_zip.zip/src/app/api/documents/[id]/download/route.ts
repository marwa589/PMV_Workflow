// src/app/api/documents/[id]/download/route.ts
import { readFile } from "fs/promises";
import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { canAccessDocument } from "@/lib/auth/access";
import { resolveStoredFilePath } from "@/lib/files";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const { id: documentId } = await params;
  const searchParams = new URL(request.url).searchParams;
  const inline = searchParams.get("inline") === "1";

  // Viewing in the browser needs documents.view; saving a copy needs documents.download.
  // People named in the document's flow, or who created or acted on it, can always open it.
  const canAccess = await canAccessDocument(session, documentId, inline ? "documents.view" : "documents.download");
  if (!canAccess) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const document = await prisma.document.findUnique({
    where: { id: documentId },
    select: { id: true, currentVersion: true },
  });

  if (!document) {
    return NextResponse.json({ message: "Document not found." }, { status: 404 });
  }

  const versionParam = searchParams.get("version");
  const targetVersionNumber =
    versionParam !== null && !isNaN(Number(versionParam)) ? Number(versionParam) : document.currentVersion;

  const version = await prisma.documentVersion.findUnique({
    where: { documentId_versionNumber: { documentId, versionNumber: targetVersionNumber } },
    select: { filePath: true, originalName: true, mimeType: true },
  });

  if (!version) {
    return NextResponse.json({ message: "Document version not found." }, { status: 404 });
  }

  try {
    const buffer = await readFile(resolveStoredFilePath(version.filePath));

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "Content-Type": version.mimeType || "application/octet-stream",
        "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${version.originalName}"`,
      },
    });
  } catch {
    return NextResponse.json({ message: "File not found on server." }, { status: 404 });
  }
}
