"use client";

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  File,
  FileImage,
  FileSpreadsheet,
  FileText,
  Loader2,
  UploadCloud,
  XCircle,
} from "lucide-react";
import { getCsrfTokenFromBrowser } from "@/lib/csrf";
import PurchaseOrderInvoiceUpload, { RECEIVING_UPLOAD_KIND_LABELS, type ReceivingUploadKind } from "@/components/purchase-order-invoice-upload";
import type { ReceivingUploadOptions } from "@/lib/receiving-upload-options";

type FileKind = "pdf" | "docx" | "xlsx" | "image" | "unknown";
type DocumentTypeOption = "COMPARISON" | "MATERIAL_REQUISITION" | "CUSTODY" | "ERR" | ReceivingUploadKind;

const RECEIVING_UPLOAD_KINDS: ReceivingUploadKind[] = ["INVOICE", "GRV", "CASH_RECEIVING_VOUCHER"];

function isReceivingUploadKind(value: DocumentTypeOption | null): value is ReceivingUploadKind {
  return value !== null && (RECEIVING_UPLOAD_KINDS as string[]).includes(value);
}
type MrTypeOption = "CASH" | "CREDIT";
type ComparisonTypeOption = "SPARE_PARTS" | "OTHER";
type ErrTypeOption = "RENTAL_ACTC" | "RENTAL_EXTERNAL" | "RENEWAL" | "PURCHASE" | "RFD";

const ACCEPTED_EXTENSIONS = ["pdf", "doc", "docx", "xls", "xlsx", "jpg", "jpeg", "png"];
const ACCEPTED_MIME_TYPES = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "image/jpeg",
  "image/png",
];

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / Math.pow(1024, index);
  return `${value.toFixed(value >= 100 ? 0 : 1)} ${units[index]}`;
}

function extensionOf(fileName: string): string {
  const parts = fileName.toLowerCase().split(".");
  return parts.length > 1 ? parts[parts.length - 1] : "";
}

function fileKind(file: File): FileKind {
  const ext = extensionOf(file.name);
  if (ext === "pdf") return "pdf";
  if (ext === "docx") return "docx";
  if (ext === "xlsx") return "xlsx";
  if (ext === "jpg" || ext === "jpeg" || ext === "png") return "image";
  return "unknown";
}

function isAcceptedFile(file: File): boolean {
  const ext = extensionOf(file.name);
  return ACCEPTED_EXTENSIONS.includes(ext) || ACCEPTED_MIME_TYPES.includes(file.type);
}

function FileTypeIcon({ file }: { file: File | null }) {
  if (!file) {
    return <UploadCloud className="h-8 w-8 text-slate-500" />;
  }

  switch (fileKind(file)) {
    case "pdf":
      return <FileText className="h-8 w-8 text-rose-600" />;
    case "docx":
      return <File className="h-8 w-8 text-blue-600" />;
    case "xlsx":
      return <FileSpreadsheet className="h-8 w-8 text-emerald-600" />;
    case "image":
      return <FileImage className="h-8 w-8 text-amber-600" />;
    default:
      return <File className="h-8 w-8 text-slate-600" />;
  }
}

type ErrDirector = { projectId: string; directorId?: string; name: string; projectName: string; country?: string; accessRole?: "PROJECT_DIRECTOR" | "PROJECT_MANAGER" };

export default function NewDocumentForm({ defaultRedirectPath = "/clerk", errDirectors = [], errOnly = false, marcOnly = false, workflowRouteOptions = [], receivingUpload = null, attachmentOnly = false }: { defaultRedirectPath?: string; errDirectors?: ErrDirector[]; errOnly?: boolean; marcOnly?: boolean; /** "Location / Project" choices for MRs and comparisons (Erro and Bernabie). */ workflowRouteOptions?: Array<{ value: string; label: string }>; /** Invoice / GRV / Cash Receiving Voucher upload choices; set only for invoice uploaders. */ receivingUpload?: ReceivingUploadOptions | null; /** Show only the invoice / GRV / voucher types (uploaders who cannot create workflow documents). */ attachmentOnly?: boolean }) {
  const allowErroReadyMixMr = workflowRouteOptions.length > 0;
  const router = useRouter();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [documentType, setDocumentType] = useState<DocumentTypeOption | null>(errOnly ? "ERR" : null);
  const [comparisonType, setComparisonType] = useState<ComparisonTypeOption | null>(null);
  const [mrType, setMrType] = useState<MrTypeOption | null>(null);
  const [mrWorkflowLocation, setMrWorkflowLocation] = useState("");
  const [comparisonWorkflowLocation, setComparisonWorkflowLocation] = useState("");
  const [errType, setErrType] = useState<ErrTypeOption | null>(null);
  const [errProjectId, setErrProjectId] = useState("");
  const [quotations, setQuotations] = useState<File[]>([]);
  const [mrNumber, setMrNumber] = useState("");
  const [comparisonLinkChoice, setComparisonLinkChoice] = useState<"YES" | "NO" | null>(null);
  const [comparisonSearch, setComparisonSearch] = useState("");
  const [comparisonOptions, setComparisonOptions] = useState<Array<{ id: string; documentNumber: string; title: string; approvedAt: string }>>([]);
  const [selectedComparisonId, setSelectedComparisonId] = useState<string | null>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [fileTitles, setFileTitles] = useState<string[]>([]);
  const errSubmissionKeys = useRef(new Map<File, string>());
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showToast, setShowToast] = useState(false);

  const fileSummary = useMemo(() => {
    if (selectedFiles.length === 0) return null;
    return selectedFiles.map((file) => ({
      name: file.name,
      size: formatBytes(file.size),
      type: file.type || "Unknown MIME type",
    }));
  }, [selectedFiles]);

  function getErrSubmissionKey(file: File): string {
    const cachedKey = errSubmissionKeys.current.get(file);
    if (cachedKey) return cachedKey;

    const storageKey = `err-submission:${file.name}:${file.size}:${file.lastModified}`;
    let submissionKey: string | null = null;
    try {
      submissionKey = window.sessionStorage.getItem(storageKey);
    } catch {
      // Continue with the in-memory key if browser storage is unavailable.
    }

    submissionKey ||= crypto.randomUUID();
    errSubmissionKeys.current.set(file, submissionKey);
    try {
      window.sessionStorage.setItem(storageKey, submissionKey);
    } catch {
      // In-memory retries remain protected for this mounted form.
    }
    return submissionKey;
  }

  function clearErrSubmissionKeys(files: File[]) {
    for (const file of files) {
      const storageKey = `err-submission:${file.name}:${file.size}:${file.lastModified}`;
      errSubmissionKeys.current.delete(file);
      try {
        window.sessionStorage.removeItem(storageKey);
      } catch {
        // Ignore unavailable browser storage.
      }
    }
  }

  function handleFileSelection(files: FileList | File[] | null) {
    const incomingFiles = Array.from(files ?? []);
    if (incomingFiles.length === 0) return;

    const invalid = incomingFiles.find((file) => !isAcceptedFile(file));
    if (invalid) {
      setError("Unsupported file type. Allowed: PDF, Word, Excel, JPG, JPEG, PNG.");
      return;
    }

    setError(null);
    const uniqueIncomingFiles = incomingFiles.filter((file) => !selectedFiles.some((existing) => existing.name === file.name && existing.size === file.size));
    if (documentType === "ERR" && !title.trim() && selectedFiles.length === 0) {
      setTitle(incomingFiles[0].name.replace(/\.[^.]+$/, ""));
    }
    setSelectedFiles((current) => [...current, ...uniqueIncomingFiles]);
    setFileTitles((current) => [...current, ...uniqueIncomingFiles.map((file) => file.name.replace(/\.[^.]+$/, ""))]);
  }

  function onDrop(e: React.DragEvent<HTMLLabelElement>) {
    e.preventDefault();
    setIsDragging(false);

    handleFileSelection(e.dataTransfer.files);
  }

  function onDragOver(e: React.DragEvent<HTMLLabelElement>) {
    e.preventDefault();
    setIsDragging(true);
  }

  function onDragLeave(e: React.DragEvent<HTMLLabelElement>) {
    e.preventDefault();
    setIsDragging(false);
  }

  function resetForm() {
    clearErrSubmissionKeys(selectedFiles);
    setTitle("");
    setDescription("");
    setDocumentType(errOnly ? "ERR" : null);
    setComparisonType(null);
    setMrType(null);
    setMrWorkflowLocation("");
    setComparisonWorkflowLocation("");
    setErrType(null);
    setErrProjectId("");
    setQuotations([]);
    setMrNumber("");
    setComparisonLinkChoice(null);
    setComparisonSearch("");
    setComparisonOptions([]);
    setSelectedComparisonId(null);
    setSelectedFiles([]);
    setFileTitles([]);
    setError(null);
  }

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    if (!documentType) {
      setError("Please select a document type.");
      return;
    }

    if (documentType === "MATERIAL_REQUISITION" && !mrType) {
      setError("Please select an MR type.");
      return;
    }

    if (documentType === "MATERIAL_REQUISITION" && allowErroReadyMixMr && !mrWorkflowLocation) {
      setError("Please select the MR location or project.");
      return;
    }

    if (documentType === "COMPARISON" && !comparisonType) {
      setError("Please select a comparison type.");
      return;
    }

    if (documentType === "COMPARISON" && allowErroReadyMixMr && !comparisonWorkflowLocation) {
      setError("Please select the comparison location or project.");
      return;
    }

    if (documentType === "ERR" && (!errType || (!marcOnly && !errProjectId))) {
      setError(marcOnly ? "Please select an ERR type." : "Please select an ERR type and project.");
      return;
    }

    if (selectedFiles.length === 0) {
      setError("Please upload at least one file before creating.");
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      if (documentType === "ERR") {
        for (const [index, file] of selectedFiles.entries()) {
          const errFormData = new FormData();
          errFormData.set("title", file.name.replace(/\.[^.]+$/, ""));
          errFormData.set("description", description);
          errFormData.set("type", errType || "");
          if (marcOnly) errFormData.set("marcOnly", "true");

          if (!marcOnly) {
            const [projId, dirId] = errProjectId.split("::");
            errFormData.set("projectId", projId);
            if (dirId) {
              errFormData.set("projectDirectorId", dirId);
            }
          }

          errFormData.set("submissionKey", getErrSubmissionKey(file));
          errFormData.append("files", file);
          if (index === 0) quotations.forEach((file) => errFormData.append("quotations", file));

          const response = await fetch("/api/errs", {
            method: "POST",
            headers: { "x-csrf-token": getCsrfTokenFromBrowser() },
            body: errFormData,
          });
          const result = (await response.json()) as { message?: string };
          if (!response.ok) {
            setError(result.message || `Failed to create ERR ${index + 1}.`);
            setIsSubmitting(false);
            return;
          }
        }

        setIsSubmitting(false);
        setShowToast(true);
        resetForm();
        window.setTimeout(() => {
          setShowToast(false);
          router.push(defaultRedirectPath);
          router.refresh();
        }, 1600);
        return;
      }

      const formData = new FormData();
      formData.set("title", title);
      formData.set("description", description);
      formData.set("documentType", documentType);
      if (documentType === "COMPARISON" && comparisonType) {
        formData.set("comparisonType", comparisonType);
      }
      if (documentType === "COMPARISON" && allowErroReadyMixMr) {
        formData.set("comparisonWorkflowLocation", comparisonWorkflowLocation);
      }

      if (documentType === "CUSTODY") {
        formData.set("documentType", "CUSTODY");
      }
      if (documentType === "MATERIAL_REQUISITION") {
        if (allowErroReadyMixMr) {
          formData.set("mrWorkflowLocation", mrWorkflowLocation);
        }
        if (mrType) {
          formData.set("mrType", mrType);
        }
        if (mrNumber.trim()) {
          formData.set("mrNumber", mrNumber.trim());
        }
        if (comparisonLinkChoice === "YES" && selectedComparisonId) {
          formData.set("relatedComparisonId", selectedComparisonId);
        } else {
          formData.set("relatedComparisonId", "");
        }
      }
      selectedFiles.forEach((file, index) => {
        formData.append("files", file);
        formData.append("fileTitles", fileTitles[index] || file.name.replace(/\.[^.]+$/, ""));
      });

      const response = await fetch("/api/documents", {
        method: "POST",
        headers: { "x-csrf-token": getCsrfTokenFromBrowser() },
        body: formData,
      });

      const result = (await response.json()) as { message?: string };
      if (!response.ok) {
        setError(result.message || "Failed to create document.");
        setIsSubmitting(false);
        return;
      }

      setIsSubmitting(false);
      setShowToast(true);
      resetForm();
      window.setTimeout(() => {
        setShowToast(false);
        router.push(defaultRedirectPath);
        router.refresh();
      }, 1600);
    } catch {
      setIsSubmitting(false);
      setError("Unexpected error while submitting document.");
    }
  }

  const typeOptions: Array<{ value: DocumentTypeOption; label: string }> = [
    ...(attachmentOnly
      ? []
      : errOnly
        ? [{ value: "ERR" as const, label: "ERR" }]
        : [
            { value: "COMPARISON" as const, label: "Comparison Sheet" },
            { value: "MATERIAL_REQUISITION" as const, label: "Material Requisition" },
            { value: "CUSTODY" as const, label: "Custody File" },
            { value: "ERR" as const, label: "ERR" },
          ]),
    ...(receivingUpload
      ? RECEIVING_UPLOAD_KINDS.map((kind) => ({ value: kind, label: RECEIVING_UPLOAD_KIND_LABELS[kind] }))
      : []),
  ];

  const typePicker = errOnly && !receivingUpload ? (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-700">
        Document Type
      </label>
      <div className="rounded-xl border-2 border-cyan-500 bg-cyan-50 px-4 py-3 text-sm font-medium text-cyan-700">
        ERR
      </div>
    </div>
  ) : (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-700">
        Document Type <span className="text-rose-600">*</span>
      </label>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {typeOptions.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => {
              setDocumentType(option.value);
              setError(null);
              if (option.value === "COMPARISON") {
                setMrType(null);
                setErrType(null);
              } else if (option.value === "MATERIAL_REQUISITION") {
                setComparisonType(null);
                setErrType(null);
              } else {
                setComparisonType(null);
                setMrType(null);
              }
            }}
            className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
              documentType === option.value
                ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );

  if (receivingUpload && isReceivingUploadKind(documentType)) {
    return (
      <div className="space-y-6">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <h2 className="text-base font-semibold text-slate-900">Document Details</h2>
          <div className="mt-4">{typePicker}</div>
        </section>
        <PurchaseOrderInvoiceUpload
          key={documentType}
          kind={documentType}
          purchaseOrders={receivingUpload.purchaseOrders}
          cashMrs={receivingUpload.cashMrs}
          grvInvoices={receivingUpload.grvInvoices}
          voucherCashMrs={receivingUpload.voucherCashMrs}
        />
      </div>
    );
  }

  if (attachmentOnly) {
    return (
      <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <h2 className="text-base font-semibold text-slate-900">Document Details</h2>
        <div className="mt-4">{typePicker}</div>
      </section>
    );
  }

  return (
    <>
      {showToast && (
        <div className="fixed right-4 top-4 z-50 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-900 shadow-lg">
          <div className="flex items-center gap-2 text-sm font-medium">
            <CheckCircle2 className="h-4 w-4" />
            Document created successfully
          </div>
        </div>
      )}

      <form onSubmit={onSubmit} className="space-y-6">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <h2 className="text-base font-semibold text-slate-900">Document Details</h2>

          <div className="mt-4 grid grid-cols-1 gap-5">
            {typePicker}

            {documentType === "COMPARISON" ? (
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <label className="block text-sm font-medium text-slate-700">
                  Comparison Type <span className="text-rose-600">*</span>
                </label>
                <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {[
                    { value: "SPARE_PARTS", label: "Spare Parts Comparison" },
                    { value: "OTHER", label: "Other Comparison" },
                  ].map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setComparisonType(option.value as ComparisonTypeOption)}
                      className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                        comparisonType === option.value
                          ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                          : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
                {allowErroReadyMixMr ? (
                  <div className="mt-4">
                    <label className="mb-2 block text-sm font-medium text-slate-700">
                      Comparison Location / Project <span className="text-rose-600">*</span>
                    </label>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      {workflowRouteOptions.map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => setComparisonWorkflowLocation(option.value)}
                          className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                            comparisonWorkflowLocation === option.value
                              ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                              : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                          }`}
                          aria-pressed={comparisonWorkflowLocation === option.value}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : null}
              </div>
            ) : null}

            {documentType === "MATERIAL_REQUISITION" ? (
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="flex items-center justify-between gap-3">
                  <label className="block text-sm font-medium text-slate-700">
                    MR Details <span className="text-rose-600">*</span>
                  </label>
                </div>

                <div className="mt-3 grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <label htmlFor="mr-number" className="mb-2 block text-sm font-medium text-slate-700">
                      MR Number
                    </label>
                    <input
                      id="mr-number"
                      type="text"
                      value={mrNumber}
                      onChange={(e) => setMrNumber(e.target.value)}
                      placeholder="e.g. 205523"
                      className="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none ring-cyan-300 transition focus:ring-2"
                    />
                  </div>

                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-700">
                      MR Type <span className="text-rose-600">*</span>
                    </label>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      {[
                        { value: "CASH", label: "Cash" },
                        { value: "CREDIT", label: "Credit" },
                      ].map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => setMrType(option.value as MrTypeOption)}
                          className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                            mrType === option.value
                              ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                              : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {allowErroReadyMixMr ? (
                  <div className="mt-4">
                    <label className="mb-2 block text-sm font-medium text-slate-700">
                      MR Location / Project <span className="text-rose-600">*</span>
                    </label>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      {workflowRouteOptions.map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => {
                            setMrWorkflowLocation(option.value);
                            setSelectedComparisonId(null);
                            setComparisonSearch("");
                            setComparisonOptions([]);
                          }}
                          className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${
                            mrWorkflowLocation === option.value
                              ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                              : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                          }`}
                          aria-pressed={mrWorkflowLocation === option.value}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : null}

                <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4">
                  <label className="block text-sm font-medium text-slate-700">
                    Does this MR have a related Comparison?
                  </label>
                  <div className="mt-3 flex flex-wrap gap-3">
                    {(["YES", "NO"] as const).map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => {
                          setComparisonLinkChoice(option);
                          if (option === "NO") {
                            setSelectedComparisonId(null);
                            setComparisonSearch("");
                            setComparisonOptions([]);
                          }
                        }}
                        className={`rounded-xl border px-4 py-2 text-sm font-medium transition ${
                          comparisonLinkChoice === option
                            ? "border-cyan-500 bg-cyan-50 text-cyan-700"
                            : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"
                        }`}
                      >
                        {option === "YES" ? "Yes" : "No"}
                      </button>
                    ))}
                  </div>

                  {comparisonLinkChoice === "YES" ? (
                    <div className="mt-4 space-y-3">
                      <input
                        value={comparisonSearch}
                        onChange={async (event) => {
                          const value = event.target.value;
                          setComparisonSearch(value);
                          if (!value.trim()) {
                            setComparisonOptions([]);
                            return;
                          }

                          try {
                            const workflowLocation = allowErroReadyMixMr && mrWorkflowLocation ? `&workflowLocation=${mrWorkflowLocation}` : "";
                            const response = await fetch(`/api/documents/comparisons?search=${encodeURIComponent(value.trim())}${workflowLocation}`);
                            const result = (await response.json()) as { comparisons?: Array<{ id: string; documentNumber: string; title: string; approvedAt: string }> };
                            setComparisonOptions(result.comparisons || []);
                          } catch {
                            setComparisonOptions([]);
                          }
                        }}
                        placeholder="Search approved comparisons"
                        className="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none ring-cyan-300 transition focus:ring-2"
                      />
                      {comparisonOptions.length > 0 ? (
                        <div className="max-h-48 space-y-2 overflow-auto rounded-xl border border-slate-200 bg-slate-50 p-2">
                          {comparisonOptions.map((comparison) => (
                            <button
                              key={comparison.id}
                              type="button"
                              onClick={() => setSelectedComparisonId(comparison.id)}
                              className={`w-full rounded-lg border px-3 py-2 text-left text-sm transition ${
                                selectedComparisonId === comparison.id
                                  ? "border-cyan-500 bg-cyan-100 text-cyan-800"
                                  : "border-transparent bg-white text-slate-700 hover:border-slate-200"
                              }`}
                            >
                              <div className="font-semibold">{comparison.documentNumber}</div>
                              <div className="text-xs text-slate-600">{comparison.title}</div>
                              <div className="mt-1 text-[11px] text-slate-500">Approved {comparison.approvedAt}</div>
                            </button>
                          ))}
                        </div>
                      ) : null}
                      {selectedComparisonId ? (
                        <p className="text-sm text-slate-600">
                          Selected comparison: <span className="font-semibold text-slate-900">{comparisonOptions.find((item) => item.id === selectedComparisonId)?.documentNumber || "Selected"}</span>
                        </p>
                      ) : (
                        <p className="text-sm text-slate-500">Search and select one approved comparison.</p>
                      )}
                    </div>
                  ) : null}
                </div>

                <p className="mt-3 text-sm text-slate-600">
                  Enter the MR number and choose the MR type manually before saving.
                </p>
              </div>
            ) : null}

            {documentType === "ERR" ? (
              <div className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700">ERR Type <span className="text-rose-600">*</span></label>
                  <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
                    {[
                      { value: "RENTAL_ACTC", label: "Rental ACTC" },
                      { value: "RENTAL_EXTERNAL", label: "Rental External" },
                      { value: "RENEWAL", label: "Renewal" },
                      { value: "PURCHASE", label: "Purchase" },
                      { value: "RFD", label: "RFD (Request for Diesel)" },
                    ].map((option) => (
                      <button key={option.value} type="button" onClick={() => setErrType(option.value as ErrTypeOption)} className={`rounded-xl border px-4 py-3 text-left text-sm font-medium transition ${errType === option.value ? "border-cyan-500 bg-cyan-50 text-cyan-700" : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`}>
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
                {!marcOnly ? <div>
                  <label htmlFor="err-project" className="mb-2 block text-sm font-medium text-slate-700">Project Director or Project Manager <span className="text-rose-600">*</span></label>
                  <select id="err-project" value={errProjectId} onChange={(event) => setErrProjectId(event.target.value)} className="block w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none focus:border-slate-500">
                    <option value="">Select a project approver</option>
                    {errDirectors.map((director) => (
                      <option key={`${director.projectId}::${director.directorId}`} value={`${director.projectId}::${director.directorId}`}>
                        {director.name} - {director.accessRole === "PROJECT_MANAGER" ? "Project Manager" : "Project Director"} - {director.projectName}
                      </option>
                    ))}
                  </select>
                  {errProjectId ? (
                    <div className="mt-2 rounded-lg bg-blue-50 px-3 py-2 text-sm text-blue-700 border border-blue-200">
                      <span className="font-medium">Country:</span> {errDirectors.find((director) => `${director.projectId}::${director.directorId}` === errProjectId)?.country || "KUWAIT"}
                    </div>
                  ) : null}
                </div> : null}
                <div>
                  <label htmlFor="err-quotation" className="mb-2 block text-sm font-medium text-slate-700">Quotation <span className="font-normal text-slate-500">(optional)</span></label>
                  <input id="err-quotation" type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" onChange={(event) => setQuotations(Array.from(event.target.files ?? []))} className="block w-full rounded-lg border border-slate-300 bg-white text-sm text-slate-700 file:mr-3 file:cursor-pointer file:border-0 file:bg-blue-600 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-white hover:file:bg-blue-700" />
                  {quotations.length > 0 ? (
                    <ul className="mt-2 space-y-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">
                      {quotations.map((file, index) => (
                        <li key={`${file.name}-${file.size}-${file.lastModified}`} className="flex min-w-0 items-center justify-between gap-3" title={file.name}>
                          <span className="truncate">{file.name}</span>
                          <button type="button" onClick={() => setQuotations((current) => current.filter((_, fileIndex) => fileIndex !== index))} aria-label={`Remove ${file.name}`} title="Remove quotation" className="inline-flex shrink-0 items-center gap-1.5 rounded border border-rose-300 bg-rose-50 px-3 py-1.5 font-semibold text-rose-800 transition hover:bg-rose-100">
                            <XCircle size={14} aria-hidden="true" />
                            Remove quotation
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </div>
            ) : null}

            <div>
              <label htmlFor="description" className="mb-2 block text-sm font-medium text-slate-700">
                Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                placeholder="Add optional context for approvers"
                className="w-full rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none ring-cyan-300 transition focus:ring-2"
              />
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
          <h2 className="text-base font-semibold text-slate-900">Upload File</h2>
          <p className="mt-1 text-xs text-slate-500">Accepted: PDF, Word, Excel, JPG, JPEG, PNG. You can upload multiple files.</p>

          <label
            htmlFor="file-input"
            onDrop={onDrop}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            className={`mt-4 block cursor-pointer rounded-2xl border-2 border-dashed p-6 transition sm:p-8 ${
              isDragging ? "border-cyan-500 bg-cyan-50" : "border-slate-300 bg-slate-50 hover:border-slate-400"
            }`}
          >
            <div className="flex flex-col items-center gap-3 text-center">
              <FileTypeIcon file={selectedFiles[0] ?? null} />
              <div>
                <p className="text-sm font-medium text-slate-800">Drag and drop files here, or click to browse</p>
                <p className="mt-1 text-xs text-slate-500">
                  {documentType === "MATERIAL_REQUISITION"
                    ? "Choose the MR type above, then upload the file for this requisition."
                    : documentType === "ERR"
                      ? "Upload one primary ERR file. Add a quotation separately if needed."
                      : "Upload one or more files. Each file will become its own document."}
                </p>
              </div>
            </div>

            <input
              id="file-input"
              type="file"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
              className="sr-only"
              multiple
              onChange={(e) => handleFileSelection(e.target.files)}
            />
          </label>

          {fileSummary && (
            <div className="mt-4 space-y-3 rounded-xl border border-slate-200 bg-white p-4">
              {fileSummary.map((file, index) => (
                <div key={`${file.name}-${index}`} className="flex items-start justify-between gap-3 rounded-lg border border-slate-100 p-3">
                  <div className="flex items-start gap-3">
                    <FileTypeIcon file={selectedFiles[index] ?? null} />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-900">{file.name}</p>
                      <p className="text-xs text-slate-500">{file.size}</p>
                      <p className="text-xs text-slate-500">{file.type}</p>
                      <label className="mt-2 block text-xs font-medium text-slate-600">
                        Title
                        <input
                          type="text"
                          value={fileTitles[index] || ""}
                          onChange={(e) => {
                            const nextTitles = [...fileTitles];
                            nextTitles[index] = e.target.value;
                            setFileTitles(nextTitles);
                          }}
                          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none ring-cyan-300 transition focus:ring-2"
                          placeholder="Enter document title"
                        />
                      </label>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedFiles((current) => current.filter((_, itemIndex) => itemIndex !== index));
                      setFileTitles((current) => current.filter((_, itemIndex) => itemIndex !== index));
                    }}
                    className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-600 hover:bg-slate-100"
                  >
                    <XCircle className="h-4 w-4" />
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}

          {error && (
            <div className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
              {error}
            </div>
          )}
        </section>

        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={() => router.push(defaultRedirectPath)}
            disabled={isSubmitting}
            className="inline-flex items-center justify-center rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
          >
            Cancel
          </button>

          <button
            type="submit"
            disabled={isSubmitting}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Document"
            )}
          </button>
        </div>
      </form>
    </>
  );
}
