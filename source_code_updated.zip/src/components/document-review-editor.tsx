"use client";

import { PDFDocument, degrees, rgb } from "pdf-lib";
import type { PDFDocumentProxy } from "pdfjs-dist";
import { ArrowLeft, Check, Download, Loader2, PenLine, RotateCw, Trash2, Type } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { getCsrfTokenFromBrowser } from "@/lib/csrf";

type PageInfo = { pageNumber: number; width: number; height: number };
type Placement = { id: string; pageNumber: number; x: number; y: number; width: number; height: number; rotation: number };
type CirclePlacement = { id: string; pageNumber: number; x: number; y: number; width: number; height: number };
type TextBoxPlacement = { id: string; pageNumber: number; x: number; y: number; width: number; height: number; text: string; color: string; fontSize: number };
type DragState = { id: string; startX: number; startY: number; origin: Placement; mode: "drag" | "resize" };
type CircleDragState = { id: string; pageNumber: number; startX: number; startY: number; rect: DOMRect };
type TextBoxDragState = { id: string; pageNumber: number; startX: number; startY: number; rect: DOMRect };

function clamp(value: number, min: number, max: number) { return Math.max(min, Math.min(max, value)); }
function isPdf(file: File) { return file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf"); }

async function loadPdfJs() {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  pdfjs.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/legacy/build/pdf.worker.mjs", import.meta.url).toString();
  return pdfjs;
}

type RedirectUserOption = { id: string; name: string; email: string };

function RedirectUserSearch({ users, value, onChange, disabled }: { users: RedirectUserOption[]; value: string; onChange: (userId: string) => void; disabled?: boolean }) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const selected = users.find((user) => user.id === value) || null;
  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const matches = needle
      ? users.filter((user) => user.name.toLowerCase().includes(needle) || user.email.toLowerCase().includes(needle))
      : users;
    return matches.slice(0, 50);
  }, [query, users]);

  return (
    <div className="relative">
      <input
        id="review-redirect-user"
        type="text"
        role="combobox"
        aria-expanded={open}
        aria-autocomplete="list"
        autoComplete="off"
        disabled={disabled}
        value={open ? query : selected ? `${selected.name} (${selected.email})` : ""}
        onFocus={() => { setQuery(""); setOpen(true); }}
        onBlur={() => setOpen(false)}
        onChange={(event) => { setQuery(event.target.value); setOpen(true); }}
        onKeyDown={(event) => {
          if (event.key === "Escape") setOpen(false);
          if (event.key === "Enter" && open && filtered[0]) {
            event.preventDefault();
            onChange(filtered[0].id);
            setOpen(false);
          }
        }}
        placeholder="Search by name or email"
        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
      />
      {open ? (
        <ul role="listbox" className="absolute z-40 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-slate-200 bg-white py-1 text-sm shadow-lg">
          {filtered.length === 0 ? <li className="px-3 py-2 text-slate-500">No users match "{query}".</li> : filtered.map((user) => (
            <li key={user.id} role="option" aria-selected={user.id === value}>
              <button
                type="button"
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => { onChange(user.id); setQuery(""); setOpen(false); }}
                className={`flex w-full flex-col items-start px-3 py-2 text-left hover:bg-slate-100 ${user.id === value ? "bg-slate-50" : ""}`}
              >
                <span className="font-medium text-slate-900">{user.name}</span>
                <span className="text-xs text-slate-500">{user.email}</span>
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

type DocumentReviewEditorProps = {
  documentId: string;
  documentNumber: string;
  title: string;
  errStage?: "PROJECT_DIRECTOR" | "PMV_MANAGER" | "ACTING_CEO" | "CEO";
  hasSignature: boolean;
  allowNoSignature?: boolean;
  allowQuotationUpload?: boolean;
  allowApprovalRouteSelection?: boolean;
  /** Users Marc can redirect the document to; when set, the "Redirect Document" decision is offered. */
  redirectUsers?: RedirectUserOption[];
  /** Set when the document was redirected to the current reviewer. */
  redirectedByName?: string | null;
  redirectFallback?: "FULLY_APPROVE" | "BACK_TO_REDIRECTOR" | null;
  /** ERRs: a redirected ERR always comes back to Marc, so no "Fallback to" choice is shown. */
  redirectBackToRedirectorOnly?: boolean;
  /** Hide the ERR approval path (the person Marc redirected an ERR to does not pick it). */
  hideApprovalRoute?: boolean;
  downloadUrl?: string;
  actionUrl?: string;
  returnUrl?: string;
  allowHold?: boolean;
  batchMode?: boolean;
  batchActive?: boolean;
  batchSubmitting?: boolean;
  batchDecision?: "APPROVE" | "REJECT" | "COMMENT";
  onBatchDecisionChange?: (decision: "APPROVE" | "REJECT" | "COMMENT") => void;
  onBatchSubmit?: () => void;
  onBatchAction?: (documentId: string, action: { validate: (decision: "APPROVE" | "REJECT" | "COMMENT") => string | null; submit: (decision: "APPROVE" | "REJECT" | "COMMENT") => Promise<boolean> } | null) => void;
};

export default function DocumentReviewEditor({
  documentId,
  documentNumber,
  title,
  errStage,
  hasSignature,
  allowNoSignature = false,
  allowQuotationUpload = false,
  allowApprovalRouteSelection = false,
  redirectUsers,
  redirectedByName = null,
  redirectFallback = null,
  redirectBackToRedirectorOnly = false,
  hideApprovalRoute = false,
  downloadUrl = `/api/documents/${documentId}/download`,
  actionUrl = `/api/documents/${documentId}/actions`,
  returnUrl = "/approver/pending-approvals",
  allowHold = false,
  batchMode = false,
  batchActive = false,
  batchSubmitting = false,
  batchDecision = "APPROVE",
  onBatchDecisionChange,
  onBatchSubmit,
  onBatchAction,
}: DocumentReviewEditorProps) {
  const router = useRouter();
  const pageRefs = useRef<Record<number, HTMLDivElement | null>>({});
  const canvasRefs = useRef<Record<number, HTMLCanvasElement | null>>({});
  const pdfBytesRef = useRef<Uint8Array | null>(null);
  const pdfJsDocumentRef = useRef<PDFDocumentProxy | null>(null);
  const [pages, setPages] = useState<PageInfo[]>([]);
  const [signatureUrl, setSignatureUrl] = useState<string | null>(null);
  const [signatureRatio, setSignatureRatio] = useState(3);
  const [preferredSignatureWidth, setPreferredSignatureWidth] = useState(24);
  const [placements, setPlacements] = useState<Placement[]>([]);
  const [circles, setCircles] = useState<CirclePlacement[]>([]);
  const [textBoxes, setTextBoxes] = useState<TextBoxPlacement[]>([]);
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [circleMode, setCircleMode] = useState(false);
  const [circleDrag, setCircleDrag] = useState<CircleDragState | null>(null);
  const [textBoxMode, setTextBoxMode] = useState(false);
  const [textBoxDrag, setTextBoxDrag] = useState<TextBoxDragState | null>(null);
  const [textBoxColor, setTextBoxColor] = useState("#0f172a");
  const [textBoxFontSize, setTextBoxFontSize] = useState(12);
  const [selectedTextBoxId, setSelectedTextBoxId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [decision, setDecision] = useState<"APPROVE" | "REJECT" | "COMMENT" | "HOLD" | "REDIRECT">("APPROVE");
  const [redirectToUserId, setRedirectToUserId] = useState("");
  const [redirectFallbackChoice, setRedirectFallbackChoice] = useState<"" | "FULLY_APPROVE" | "BACK_TO_REDIRECTOR">("");
  const allowRedirect = Boolean(redirectUsers && !batchMode);
  const itemLabel = errStage ? "ERR" : "document";
  const [approvalRoute, setApprovalRoute] = useState<"FINALIZE" | "ACTING_CEO" | "ACTING_CEO_THEN_CEO" | "CEO" | "MANAGING_DIRECTOR">("FINALIZE");
  const [comments, setComments] = useState("");
  const [quotationFile, setQuotationFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [signing, setSigning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  const activePlacement = useMemo(() => placements[placements.length - 1] || null, [placements]);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/auth/signature-preference", { cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) return null;
        return response.json() as Promise<{ preferredSignatureWidth?: number }>;
      })
      .then((result) => {
        if (!cancelled && typeof result?.preferredSignatureWidth === "number") {
          setPreferredSignatureWidth(result.preferredSignatureWidth);
        }
      })
      .catch(() => undefined);
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const startedAt = performance.now();
      try {
        const pdfjs = await loadPdfJs();
        const response = await fetch(downloadUrl, {
  cache: "no-store",
});
        if (!response.ok) throw new Error("Unable to load the current PDF version.");
        const pdfBytes = new Uint8Array(await response.arrayBuffer());
        const pdf = await pdfjs.getDocument({
          data: pdfBytes.slice(),
          wasmUrl: new URL("/pdfjs/wasm/", window.location.href).toString(),
        }).promise;
        pdfBytesRef.current = pdfBytes;
        pdfJsDocumentRef.current = pdf;
        const nextPages: PageInfo[] = [];
        for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
          const page = await pdf.getPage(pageNumber);
          const viewport = page.getViewport({ scale: 1 });
          nextPages.push({ pageNumber, width: viewport.width, height: viewport.height });
        }
        if (!cancelled) setPages(nextPages);
        console.info(`[review] PDF loaded in ${Math.round(performance.now() - startedAt)}ms`, { documentId, pages: pdf.numPages, bytes: pdfBytes.byteLength });
      } catch {
        if (!cancelled) setError("Unable to display the current PDF version.");
      }
    }
    void load();
    return () => { cancelled = true; };
  }, [documentId, downloadUrl]);

  useEffect(() => {
    if (!hasSignature) return;
    const image = new Image();
    image.onload = () => {
      const ratio = image.naturalWidth / image.naturalHeight || 3;
      setSignatureRatio(ratio);
      setPlacements((current) => current.map((item) => {
        const page = pages.find((value) => value.pageNumber === item.pageNumber);
        if (!page) return item;
        const height = clamp(((item.width / 100) * page.width / ratio / page.height) * 100, 4, 100 - item.y);
        return { ...item, height };
      }));
    };
    image.src = "/api/auth/signature";
    setSignatureUrl("/api/auth/signature");
  }, [hasSignature, pages]);

  useEffect(() => {
    if (!pages.length) return;
    let cancelled = false;
    async function render() {
      const pdf = pdfJsDocumentRef.current;
      if (!pdf) return;
      const startedAt = performance.now();
      for (const info of pages) {
        if (cancelled) return;
        const page = await pdf.getPage(info.pageNumber);
        const element = pageRefs.current[info.pageNumber];
        const canvas = canvasRefs.current[info.pageNumber];
        const rect = element?.getBoundingClientRect();
        if (!canvas || !rect?.width) continue;
        const dpr = Math.min(window.devicePixelRatio || 1, 3);
        const cssScale = rect.width / page.getViewport({ scale: 1 }).width;
        const viewport = page.getViewport({ scale: cssScale * dpr });
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        canvas.style.width = "100%";
        canvas.style.height = "100%";
        const context = canvas.getContext("2d");
        if (context) await page.render({ canvasContext: context, canvas, viewport }).promise;
      }
      console.info(`[review] PDF rendered in ${Math.round(performance.now() - startedAt)}ms`, { documentId, pages: pages.length, zoom });
    }
    void render().catch(() => setError("Unable to render the PDF preview."));
    const resize = () => void render();
    window.addEventListener("resize", resize);
    return () => { cancelled = true; window.removeEventListener("resize", resize); };
  }, [documentId, pages, zoom]);

  useEffect(() => {
    if (!dragState) return;
    const activeDrag = dragState;
    function pageAt(x: number, y: number) {
      return pages.find((page) => {
        const rect = pageRefs.current[page.pageNumber]?.getBoundingClientRect();
        return rect && x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
      });
    }
    function move(event: PointerEvent) {
      const origin = activeDrag.origin;
      const targetPage = activeDrag.mode === "drag" ? pageAt(event.clientX, event.clientY) || pages.find((p) => p.pageNumber === origin.pageNumber) : pages.find((p) => p.pageNumber === origin.pageNumber);
      const rect = targetPage ? pageRefs.current[targetPage.pageNumber]?.getBoundingClientRect() : null;
      if (!rect) return;
      if (activeDrag.mode === "drag") {
        const x = ((event.clientX - rect.left) / rect.width) * 100;
        const y = ((event.clientY - rect.top) / rect.height) * 100;
        setPlacements((current) => current.map((item) => item.id === origin.id ? { ...item, pageNumber: targetPage?.pageNumber || origin.pageNumber, x: clamp(x - origin.width / 2, 0, 100 - origin.width), y: clamp(y - origin.height / 2, 0, 100 - origin.height) } : item));
      } else {
        const dx = ((event.clientX - activeDrag.startX) / rect.width) * 100;
        const width = clamp(origin.width + dx, 8, 100 - origin.x);
        const height = clamp(((width / 100) * rect.width / signatureRatio / rect.height) * 100, 4, 100 - origin.y);
        setPlacements((current) => current.map((item) => item.id === origin.id ? { ...item, width, height } : item));
      }
    }
    const end = (event: PointerEvent) => {
      if (activeDrag.mode === "resize") {
        const pageRect = pageRefs.current[activeDrag.origin.pageNumber]?.getBoundingClientRect();
        if (pageRect?.width && pageRect.height) {
          const dx = ((event.clientX - activeDrag.startX) / pageRect.width) * 100;
          const width = clamp(activeDrag.origin.width + dx, 8, 100 - activeDrag.origin.x);
          const height = clamp(((width / 100) * pageRect.width / signatureRatio / pageRect.height) * 100, 4, 100 - activeDrag.origin.y);
          setPlacements((current) => current.map((item) => item.id === activeDrag.id ? { ...item, width, height } : item));
          setPreferredSignatureWidth(width);
          void fetch("/api/auth/signature-preference", {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              "x-csrf-token": getCsrfTokenFromBrowser(),
            },
            body: JSON.stringify({ preferredSignatureWidth: width }),
          }).then((response) => {
            if (!response.ok) console.warn("Unable to save preferred signature size.");
          }).catch(() => console.warn("Unable to save preferred signature size."));
        }
      }
      setDragState(null);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); };
  }, [dragState, pages, signatureRatio]);

  useEffect(() => {
    if (!circleDrag) return;
    const activeCircle = circleDrag;
    function move(event: PointerEvent) {
      const endX = clamp(((event.clientX - activeCircle.rect.left) / activeCircle.rect.width) * 100, 0, 100);
      const endY = clamp(((event.clientY - activeCircle.rect.top) / activeCircle.rect.height) * 100, 0, 100);
      const startX = (activeCircle.startX / activeCircle.rect.width) * 100;
      const startY = (activeCircle.startY / activeCircle.rect.height) * 100;
      const width = Math.abs(endX - startX);
      const height = Math.abs(endY - startY);
      setCircles((current) => current.map((item) => item.id === activeCircle.id ? {
        ...item,
        x: Math.min(startX, endX),
        y: Math.min(startY, endY),
        width,
        height,
      } : item));
    }
    const end = () => {
      setCircleDrag(null);
      setCircleMode(false);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); };
  }, [circleDrag]);

  useEffect(() => {
    if (!textBoxDrag) return;
    const activeTextBox = textBoxDrag;
    function move(event: PointerEvent) {
      const endX = clamp(((event.clientX - activeTextBox.rect.left) / activeTextBox.rect.width) * 100, 0, 100);
      const endY = clamp(((event.clientY - activeTextBox.rect.top) / activeTextBox.rect.height) * 100, 0, 100);
      const startX = (activeTextBox.startX / activeTextBox.rect.width) * 100;
      const startY = (activeTextBox.startY / activeTextBox.rect.height) * 100;
      setTextBoxes((current) => current.map((item) => item.id === activeTextBox.id ? {
        ...item,
        x: Math.min(startX, endX),
        y: Math.min(startY, endY),
        width: Math.abs(endX - startX),
        height: Math.abs(endY - startY),
      } : item));
    }
    const end = () => {
      setTextBoxDrag(null);
      setTextBoxMode(false);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", end);
    return () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); };
  }, [textBoxDrag]);

  function startDrag(event: React.PointerEvent<HTMLElement>, placement: Placement, mode: DragState["mode"]) {
    event.preventDefault();
    event.stopPropagation();
    setDragState({ id: placement.id, startX: event.clientX, startY: event.clientY, origin: placement, mode });
  }

  function addSignature(pageNumber: number) {
    if (!signatureUrl) {
      setError("Save a signature in Account Settings before signing.");
      return;
    }
    const viewportCenter = window.innerHeight / 2;
    const visiblePage = pages
      .map((value) => ({
        pageNumber: value.pageNumber,
        rect: pageRefs.current[value.pageNumber]?.getBoundingClientRect(),
      }))
      .filter((value) => value.rect && value.rect.bottom > 0 && value.rect.top < window.innerHeight)
      .sort((left, right) => {
        const leftCenter = (left.rect!.top + left.rect!.bottom) / 2;
        const rightCenter = (right.rect!.top + right.rect!.bottom) / 2;
        return Math.abs(leftCenter - viewportCenter) - Math.abs(rightCenter - viewportCenter);
      })[0];
    const targetPageNumber = visiblePage?.pageNumber ?? pageNumber;
    const page = pages.find((value) => value.pageNumber === targetPageNumber);
    const width = preferredSignatureWidth;
    const height = page ? clamp(((width / 100) * page.width / signatureRatio / page.height) * 100, 4, 18) : 10;
    setPlacements((current) => [...current, { id: `${Date.now()}-${Math.random()}`, pageNumber: targetPageNumber, x: Math.min(12, 100 - width), y: 78, width, height, rotation: 0 }]);
    setStatus("Signature added. Drag and resize it before approving.");
  }

  function startCircle(event: React.PointerEvent<HTMLDivElement>, pageNumber: number) {
    if (textBoxMode || !circleMode || circleDrag) return; 
    const rect = event.currentTarget.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 100;
    const y = ((event.clientY - rect.top) / rect.height) * 100;
    const id = `${Date.now()}-${Math.random()}`;
    setCircles((current) => [...current, { id, pageNumber, x, y, width: 0, height: 0 }]);
    setCircleDrag({ id, pageNumber, startX: event.clientX - rect.left, startY: event.clientY - rect.top, rect });
    event.preventDefault();
  }

  function startTextBox(event: React.PointerEvent<HTMLDivElement>, pageNumber: number) {
    if (!textBoxMode || textBoxDrag) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = clamp(((event.clientX - rect.left) / rect.width) * 100, 0, 100);
    const y = clamp(((event.clientY - rect.top) / rect.height) * 100, 0, 100);
    const id = `${Date.now()}-${Math.random()}`;
    setTextBoxes((current) => [...current, { id, pageNumber, x, y, width: 0, height: 0, text: "", color: textBoxColor, fontSize: textBoxFontSize }]);
    setSelectedTextBoxId(id);
    setTextBoxDrag({ id, pageNumber, startX: event.clientX - rect.left, startY: event.clientY - rect.top, rect });
    event.preventDefault();
  }

  const validateBatch = useCallback((actionDecision: "APPROVE" | "REJECT" | "COMMENT"): string | null => {
    if (actionDecision === "APPROVE" && !hasSignature) return "Save a signature in Account Settings before approving.";
    if (actionDecision === "APPROVE" && placements.length === 0) return "Click Sign and place a signature before approving.";
    if (!pdfBytesRef.current || !pdfJsDocumentRef.current) return "The PDF is still loading. Please try again.";
    return null;
  }, [hasSignature, placements.length]);

  const submit = useCallback(async (batchSubmission = false, batchDecision?: "APPROVE" | "REJECT" | "COMMENT"): Promise<boolean> => {
    const actionDecision = batchSubmission ? batchDecision ?? "APPROVE" : decision;
    if (actionDecision === "REDIRECT") {
      if (!redirectToUserId) {
        setError(`Choose the user to redirect this ${itemLabel} to.`);
        return false;
      }
      if (!redirectBackToRedirectorOnly && !redirectFallbackChoice) {
        setError("Choose a \"Fallback to\" option: Fully approve or Back to me.");
        return false;
      }
    }
    const requiresSignature = actionDecision === "APPROVE" && !(allowNoSignature && placements.length === 0);
    if (actionDecision === "APPROVE" && placements.length === 0 && !allowNoSignature) {
      setError("Click Sign and place at least one signature before approving.");
      return false;
    }
    setSaving(true);
    setError(null);
    const startedAt = performance.now();
    try {
      const formData = new FormData();
      formData.set("decision", actionDecision);
      if ((errStage || allowApprovalRouteSelection) && actionDecision !== "REDIRECT") formData.set("approvalRoute", approvalRoute);
      formData.set("comments", comments);
      if (actionDecision === "REDIRECT") {
        formData.set("redirectToUserId", redirectToUserId);
        formData.set("redirectFallback", redirectBackToRedirectorOnly ? "BACK_TO_REDIRECTOR" : redirectFallbackChoice);
      }
      if (allowQuotationUpload && quotationFile && actionDecision !== "REDIRECT") formData.set("quotation", quotationFile);
      if (actionDecision === "APPROVE") {
        const pdfBytes = pdfBytesRef.current;
        const coordinatePdf = pdfJsDocumentRef.current;
        if (!pdfBytes || !coordinatePdf) throw new Error("The PDF is still loading. Please try again.");

        if (placements.length && signatureUrl) {
          const pdf = await PDFDocument.load(pdfBytes.slice());
          const signatureResponse = await fetch(signatureUrl);
          const signatureBlob = await signatureResponse.blob();
          const signatureBytes = await signatureBlob.arrayBuffer();
          const image = signatureBlob.type === "image/png" ? await pdf.embedPng(signatureBytes) : await pdf.embedJpg(signatureBytes);
          for (const item of placements) {
            const page = pdf.getPage(item.pageNumber - 1);
            const coordinatePage = await coordinatePdf.getPage(item.pageNumber);
            const viewport = coordinatePage.getViewport({ scale: 1 });
            const topLeft = viewport.convertToPdfPoint((item.x / 100) * viewport.width, (item.y / 100) * viewport.height);
            const topRight = viewport.convertToPdfPoint(((item.x + item.width) / 100) * viewport.width, (item.y / 100) * viewport.height);
            const bottomLeft = viewport.convertToPdfPoint((item.x / 100) * viewport.width, ((item.y + item.height) / 100) * viewport.height);
            const imageWidth = Math.hypot(topRight[0] - topLeft[0], topRight[1] - topLeft[1]);
            const imageHeight = Math.hypot(bottomLeft[0] - topLeft[0], bottomLeft[1] - topLeft[1]);
            const imageAngle = Math.atan2(topRight[1] - topLeft[1], topRight[0] - topLeft[0]) * (180 / Math.PI);
            const totalAngle = imageAngle - item.rotation;
            const totalRadians = totalAngle * (Math.PI / 180);
            const centerX = (topRight[0] + bottomLeft[0]) / 2;
            const centerY = (topRight[1] + bottomLeft[1]) / 2;
            const drawX = centerX - (Math.cos(totalRadians) * imageWidth / 2 - Math.sin(totalRadians) * imageHeight / 2);
            const drawY = centerY - (Math.sin(totalRadians) * imageWidth / 2 + Math.cos(totalRadians) * imageHeight / 2);
            page.drawImage(image, {
              x: item.rotation === 0 ? bottomLeft[0] : drawX,
              y: item.rotation === 0 ? bottomLeft[1] : drawY,
              width: imageWidth,
              height: imageHeight,
              rotate: degrees(totalAngle),
            });
          }
          for (const item of circles) {
            const page = pdf.getPage(item.pageNumber - 1);
            const coordinatePage = await coordinatePdf.getPage(item.pageNumber);
            const viewport = coordinatePage.getViewport({ scale: 1 });
            const topLeft = viewport.convertToPdfPoint((item.x / 100) * viewport.width, (item.y / 100) * viewport.height);
            const bottomRight = viewport.convertToPdfPoint(((item.x + item.width) / 100) * viewport.width, ((item.y + item.height) / 100) * viewport.height);
            const left = Math.min(topLeft[0], bottomRight[0]);
            const right = Math.max(topLeft[0], bottomRight[0]);
            const bottom = Math.min(topLeft[1], bottomRight[1]);
            const top = Math.max(topLeft[1], bottomRight[1]);
            page.drawEllipse({
              x: (left + right) / 2,
              y: (bottom + top) / 2,
              xScale: (right - left) / 2,
              yScale: (top - bottom) / 2,
              borderColor: rgb(0.85, 0.1, 0.1),
              borderWidth: 2,
            });
          }
          for (const item of textBoxes) {
            const page = pdf.getPage(item.pageNumber - 1);
            const coordinatePage = await coordinatePdf.getPage(item.pageNumber);
            const viewport = coordinatePage.getViewport({ scale: 1 });
            const topLeft = viewport.convertToPdfPoint((item.x / 100) * viewport.width, (item.y / 100) * viewport.height);
            const bottomRight = viewport.convertToPdfPoint(((item.x + item.width) / 100) * viewport.width, ((item.y + item.height) / 100) * viewport.height);
            const left = Math.min(topLeft[0], bottomRight[0]);
            const right = Math.max(topLeft[0], bottomRight[0]);
            const bottom = Math.min(topLeft[1], bottomRight[1]);
            const top = Math.max(topLeft[1], bottomRight[1]);
            const red = Number.parseInt(item.color.slice(1, 3), 16) / 255;
            const green = Number.parseInt(item.color.slice(3, 5), 16) / 255;
            const blue = Number.parseInt(item.color.slice(5, 7), 16) / 255;
            if (item.text.trim()) {
              page.drawText(item.text, { x: left + 5, y: top - item.fontSize - 4, size: item.fontSize, maxWidth: Math.max(20, right - left - 10), color: rgb(red, green, blue) });
            }
          }
          const signedBytes = await pdf.save();
          const buffer = signedBytes.buffer.slice(signedBytes.byteOffset, signedBytes.byteOffset + signedBytes.byteLength) as ArrayBuffer;
          formData.set("file", new File([buffer], `${title}-signed.pdf`, { type: "application/pdf" }));
          formData.set("signatureCount", String(placements.length));
        } else {
          const buffer = pdfBytes.slice().buffer.slice(
            pdfBytes.byteOffset,
            pdfBytes.byteOffset + pdfBytes.byteLength,
          ) as ArrayBuffer;
          formData.set("file", new File([buffer], `${title}.pdf`, { type: "application/pdf" }));
          formData.set("signatureCount", "0");
        }
      }
      console.info(`[review] Action prepared in ${Math.round(performance.now() - startedAt)}ms`, { documentId, decision: actionDecision, requiresSignature });
      const response = await fetch(actionUrl, {
  method: "POST",
  headers: {
    "x-csrf-token": getCsrfTokenFromBrowser(),
  },
  body: formData,
});
      const result = (await response.json()) as { message?: string };
      if (!response.ok) throw new Error(result.message || "Unable to process document action.");
      console.info(`[review] Action request completed in ${Math.round(performance.now() - startedAt)}ms`, { documentId, decision: actionDecision });
      if (batchSubmission) setStatus(actionDecision === "APPROVE" ? "Approved document submitted." : actionDecision === "REJECT" ? "Rejection submitted." : "Revision request submitted.");
      else {
        router.push(returnUrl);
        router.refresh();
      }
      return true;
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "Unable to process document action.");
      return false;
    } finally {
      setSaving(false);
    }
  }, [actionUrl, allowApprovalRouteSelection, allowHold, allowNoSignature, allowQuotationUpload, approvalRoute, circles, comments, decision, documentId, errStage, itemLabel, placements, quotationFile, redirectBackToRedirectorOnly, redirectFallbackChoice, redirectToUserId, returnUrl, router, signatureUrl, textBoxes, title]);

  useEffect(() => {
    if (!batchMode || !onBatchAction) return;
    onBatchAction(documentId, { validate: validateBatch, submit: (batchDecision) => submit(true, batchDecision) });
    return () => onBatchAction(documentId, null);
  }, [batchMode, documentId, onBatchAction, submit, validateBatch]);

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-8 text-slate-900 sm:px-8">
      <div className="mx-auto max-w-6xl space-y-5">
        {!batchMode ? <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div><p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">Document Review</p><h1 className="mt-2 text-2xl font-semibold">{documentNumber}</h1><p className="mt-1 text-sm text-slate-600">{title}</p></div>
          <div className="flex flex-wrap gap-2"><button type="button" onClick={() => router.back()} className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium"><ArrowLeft className="h-4 w-4" />Back</button><a href={downloadUrl} download className="inline-flex items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium"><Download className="h-4 w-4" />Download</a></div>
        </div> : <h2 className="mb-3 text-lg font-semibold">{documentNumber} <span className="font-normal text-slate-600">{title}</span></h2>}
        {!batchMode && redirectedByName !== null ? (
          <div className="rounded-xl border border-violet-200 bg-violet-50 p-4 text-sm text-violet-900">
            <span className="font-semibold">{redirectedByName || "The PMV Manager"}</span> redirected this {itemLabel} to you.{" "}
            {redirectFallback === "FULLY_APPROVE"
              ? `When you approve it, the ${itemLabel} will be fully approved.`
              : `When you approve it, the ${itemLabel} goes back to ${redirectedByName || "the PMV Manager"} for the final decision.`}
          </div>
        ) : null}
        {!batchMode ? <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex flex-wrap items-end gap-3">
            <div className="min-w-52 flex-1">
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600">Decision</label>
              <select value={decision} onChange={(event) => setDecision(event.target.value as typeof decision)} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                <option value="APPROVE">Approve</option>
                <option value="REJECT">Reject</option>
                <option value="COMMENT">Revision Required</option>
                {allowHold ? <option value="HOLD">On Hold</option> : null}
                {allowRedirect ? <option value="REDIRECT">Redirect Document</option> : null}
              </select>
            </div>
            {allowRedirect && decision === "REDIRECT" ? (
              <>
                <div className="min-w-72 flex-[2]">
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600" htmlFor="review-redirect-user">Redirect to</label>
                  <RedirectUserSearch users={redirectUsers ?? []} value={redirectToUserId} onChange={setRedirectToUserId} disabled={saving} />
                </div>
                {redirectBackToRedirectorOnly ? (
                  <p className="min-w-52 flex-1 self-center text-sm text-slate-600">When they approve, it comes back to you.</p>
                ) : <div className="min-w-52 flex-1">
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600" htmlFor="review-redirect-fallback">Fallback to</label>
                  <select id="review-redirect-fallback" value={redirectFallbackChoice} onChange={(event) => setRedirectFallbackChoice(event.target.value as typeof redirectFallbackChoice)} disabled={saving} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                    <option value="">Select…</option>
                    <option value="FULLY_APPROVE">Fully approve</option>
                    <option value="BACK_TO_REDIRECTOR">Back to me</option>
                  </select>
                </div>}
              </>
            ) : null}
            {errStage === "PMV_MANAGER" && !hideApprovalRoute && decision !== "REDIRECT" ? (
              <div className="min-w-60 flex-1">
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600">Approval path</label>
                <select value={approvalRoute} onChange={(event) => setApprovalRoute(event.target.value as typeof approvalRoute)} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                  <option value="FINALIZE">Finalize Approval</option>
                  <option value="ACTING_CEO">Send to Managing Director</option>
                  <option value="ACTING_CEO_THEN_CEO">Send to Managing Director then CEO</option>
                  <option value="CEO">Send to CEO</option>
                </select>
              </div>
            ) : null}
            {allowApprovalRouteSelection && !errStage && decision !== "REDIRECT" ? (
              <div className="min-w-60 flex-1">
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600">Approval path</label>
                <select value={approvalRoute} onChange={(event) => setApprovalRoute(event.target.value as typeof approvalRoute)} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
                  <option value="FINALIZE">Finalize Approval</option>
                  <option value="MANAGING_DIRECTOR">Send to Managing Director</option>
                </select>
              </div>
            ) : null}
            {allowQuotationUpload && decision !== "REDIRECT" ? (
              <div className="min-w-60 flex-1">
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600" htmlFor="review-quotation">Additional quotation</label>
                <input
  id="review-quotation"
  type="file"
  accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
  onChange={(event) => setQuotationFile(event.target.files?.[0] || null)}
  disabled={saving}
  className="
    w-full text-sm
    border border-slate-300 rounded-md
    file:bg-blue-600
    file:text-white
    file:border-0
    file:px-4
    file:py-2
    file:mr-3
    file:font-medium
    hover:file:bg-blue-700
    file:cursor-pointer
  "
/>
</div>
            ) : null}
            <div className="min-w-72 flex-[2]">
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-600">Comments</label>
              <input value={comments} onChange={(event) => setComments(event.target.value)} placeholder="Comments (optional)" className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
            </div>
            <button type="button" onClick={() => void submit()} disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
              Submit Action
            </button>
          </div>
        </div> : null}
        {!batchMode || batchActive ? <div className={`${batchMode ? "fixed left-1/2 top-3 z-[60] w-[calc(100%-2rem)] max-w-6xl -translate-x-1/2" : "sticky top-0 z-30"} flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-lg`}>
          <div className="flex flex-wrap items-center gap-2">
            {batchMode ? <div className="mr-2 min-w-48"><p className="text-xs font-semibold uppercase text-slate-500">Current document</p><p className="max-w-64 truncate text-sm font-semibold text-slate-900" title={`${documentNumber} - ${title}`}>{documentNumber} - {title}</p></div> : null}
            <button type="button" onClick={() => { setCircleMode(false); setTextBoxMode(false); addSignature(activePlacement?.pageNumber || 1); }} disabled={!hasSignature} className="inline-flex items-center gap-2 rounded-lg bg-cyan-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"><PenLine className="h-4 w-4" />Sign</button>
            <button type="button" onClick={() => { setTextBoxMode(false); setCircleMode((value) => !value); }} className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold ${circleMode ? "border-rose-600 bg-rose-600 text-white" : "border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100"}`} aria-pressed={circleMode} title="Circle markup tool"><span className="h-4 w-4 rounded-full border-2 border-current" />Circle</button>
            <button type="button" onClick={() => { setCircleMode(false); setTextBoxMode((value) => !value); }} className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold ${textBoxMode ? "border-slate-900 bg-slate-900 text-white" : "border-slate-300 bg-white text-slate-700 hover:bg-slate-50"}`} aria-pressed={textBoxMode} title="Insert text box"><Type className="h-4 w-4" />Text Box</button>
            {textBoxMode || selectedTextBoxId ? <><div className="flex items-center gap-1">{["#0f172a", "#dc2626", "#2563eb", "#16a34a"].map((color) => <button key={color} type="button" aria-label={`Text color ${color}`} onClick={() => { setTextBoxColor(color); if (selectedTextBoxId) setTextBoxes((current) => current.map((item) => item.id === selectedTextBoxId ? { ...item, color } : item)); }} className={`h-7 w-7 rounded-full border-2 ${textBoxColor === color ? "border-slate-900" : "border-white shadow-sm"}`} style={{ backgroundColor: color }} />)}</div><select aria-label="Text box font size" value={selectedTextBoxId ? textBoxes.find((item) => item.id === selectedTextBoxId)?.fontSize || textBoxFontSize : textBoxFontSize} onChange={(event) => { const fontSize = Number(event.target.value); setTextBoxFontSize(fontSize); if (selectedTextBoxId) setTextBoxes((current) => current.map((item) => item.id === selectedTextBoxId ? { ...item, fontSize } : item)); }} className="rounded-lg border border-slate-300 px-2 py-2 text-sm"><option value="10">10 px</option><option value="12">12 px</option><option value="14">14 px</option><option value="16">16 px</option><option value="18">18 px</option><option value="24">24 px</option></select></> : null}
            <span className="text-sm text-slate-500">{textBoxMode ? "Drag a box around the text." : circleMode ? "Drag around content to highlight it." : hasSignature ? `${placements.length} signature placement${placements.length === 1 ? "" : "s"}` : "Save a signature in Account Settings first."}</span>
          </div>
          <div className="flex items-center gap-2">{batchMode ? <select aria-label="Action for all documents" value={batchDecision} onChange={(event) => onBatchDecisionChange?.(event.target.value as "APPROVE" | "REJECT" | "COMMENT")} disabled={batchSubmitting} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"><option value="APPROVE">Approve</option><option value="REJECT">Reject</option><option value="COMMENT">Revision Required</option></select> : null}<button type="button" onClick={() => setZoom((value) => Math.max(0.75, value - 0.1))} className="rounded-lg border px-3 py-2 text-sm">−</button><span className="min-w-16 text-center text-sm">{Math.round(zoom * 100)}%</span><button type="button" onClick={() => setZoom((value) => Math.min(1.5, value + 0.1))} className="rounded-lg border px-3 py-2 text-sm">+</button>{batchMode ? <button type="button" onClick={onBatchSubmit} disabled={saving || batchSubmitting} className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">{saving || batchSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}Submit Action</button> : null}</div>
        </div> : null}
        {error ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-800">{error}</div> : null}{status ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">{status}</div> : null}
          <section className="space-y-5 rounded-2xl border border-slate-200 bg-slate-950 p-4 shadow-sm">
          {pages.map((page) => <div key={page.pageNumber} ref={(element) => { pageRefs.current[page.pageNumber] = element; }} className={`relative mx-auto overflow-visible bg-white shadow-2xl ${circleMode || textBoxMode ? "cursor-crosshair" : ""}`} style={{ width: `min(${page.width * zoom}px, calc(100vw - 2rem))`, aspectRatio: `${page.width} / ${page.height}` }} onPointerDown={(event) => { if (textBoxMode) startTextBox(event, page.pageNumber); else startCircle(event, page.pageNumber); }}><canvas ref={(element) => { canvasRefs.current[page.pageNumber] = element; }} className="absolute inset-0 h-full w-full" />{circles.filter((item) => item.pageNumber === page.pageNumber && item.width > 0 && item.height > 0).map((item) => <div key={item.id} className="absolute rounded-[50%] border-2 border-rose-600 bg-rose-200/10" style={{ left: `${item.x}%`, top: `${item.y}%`, width: `${item.width}%`, height: `${item.height}%`, pointerEvents: "none" }}><button type="button" aria-label="Delete circle" title="Delete circle" className="pointer-events-auto absolute -right-2 -top-7 rounded bg-rose-700 p-1 text-white" onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); setCircles((current) => current.filter((value) => value.id !== item.id)); }}><Trash2 className="h-3 w-3" /></button></div>)}{textBoxes.filter((item) => item.pageNumber === page.pageNumber && item.width > 0 && item.height > 0).map((item) => <div key={item.id} className={`absolute border border-slate-300 bg-white/70 ${selectedTextBoxId === item.id ? "ring-2 ring-slate-900" : ""}`} style={{ left: `${item.x}%`, top: `${item.y}%`, width: `${item.width}%`, height: `${item.height}%`, touchAction: "none" }} onPointerDown={(event) => { event.stopPropagation(); setSelectedTextBoxId(item.id); }}><textarea value={item.text} onChange={(event) => setTextBoxes((current) => current.map((value) => value.id === item.id ? { ...value, text: event.target.value } : value))} placeholder="Text" className="h-full w-full resize-none border-0 bg-transparent p-1 outline-none" style={{ color: item.color, fontSize: `${item.fontSize}px` }} /><button type="button" aria-label="Remove text box" className="absolute -right-2 -top-7 rounded bg-rose-600 p-1 text-white" onPointerDown={(event) => event.stopPropagation()} onClick={() => { setSelectedTextBoxId(null); setTextBoxes((current) => current.filter((value) => value.id !== item.id)); }}><Trash2 className="h-3 w-3" /></button></div>)}{placements.filter((item) => item.pageNumber === page.pageNumber).map((item) => <div key={item.id} className="absolute border-2 border-cyan-500 bg-cyan-100/10" style={{ left: `${item.x}%`, top: `${item.y}%`, width: `${item.width}%`, height: `${item.height}%`, touchAction: "none", transform: `rotate(${item.rotation}deg)` }} onPointerDown={(event) => startDrag(event, item, "drag")}><img src={signatureUrl || ""} alt="Saved signature" className="h-full w-full select-none object-fill" draggable={false} /><button type="button" aria-label="Rotate signature" title="Rotate signature" className="absolute -left-2 -top-7 rounded bg-cyan-700 p-1 text-white" onPointerDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); setPlacements((current) => current.map((value) => value.id === item.id ? { ...value, rotation: (value.rotation + 90) % 360 } : value)); }}><RotateCw className="h-3 w-3" /></button><button type="button" aria-label="Resize signature" className="absolute -bottom-2 -right-2 h-5 w-5 rounded-full border-2 border-white bg-cyan-700" onPointerDown={(event) => startDrag(event, item, "resize")} /><button type="button" aria-label="Remove signature placement" className="absolute -right-2 -top-7 rounded bg-rose-600 p-1 text-white" onClick={() => setPlacements((current) => current.filter((value) => value.id !== item.id))}><Trash2 className="h-3 w-3" /></button></div>)}</div>)}
        </section>
      </div>
    </main>
  );
}
