import { UserRole } from "@prisma/client";

export const APPROVER_ROLES: UserRole[] = [
  UserRole.APPROVER_1,
  UserRole.APPROVER_2,
  UserRole.APPROVER_3,
];

export function getDefaultRouteForRole(role: UserRole): string {
  switch (role) {
    case UserRole.CLERK:
      return "/clerk";
    case UserRole.APPROVER_1:
    case UserRole.APPROVER_2:
    case UserRole.APPROVER_3:
      return "/approver";
    case UserRole.ADMIN:
      return "/admin";
    case UserRole.ERR_USER:
      return "/errs?section=dashboard";
    case UserRole.KSA_VIEWER:
      return "/ksa-viewer";
    default:
      return "/login";
  }
}

export function roleLabel(role: UserRole): string {
  switch (role) {
    case UserRole.CLERK:
      return "Clerk";
    case UserRole.APPROVER_1:
      return "PMV Engineer";
    case UserRole.APPROVER_2:
      return "Workshop Manager";
    case UserRole.APPROVER_3:
      return "PMV Manager";
    case UserRole.ADMIN:
      return "Admin";
    case UserRole.KSA_VIEWER:
      return "KSA Viewer";
    default:
      return "User";
  }
}
