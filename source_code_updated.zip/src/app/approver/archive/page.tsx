import { DocumentStatus, UserRole } from "@prisma/client";
import DashboardShell from "@/components/dashboard-shell";
import DocumentListTable from "@/components/document-list-table";
import PageSummaryCards from "@/components/page-summary-cards";
import { requireRole } from "@/lib/auth/guards";
import { getDocumentsForApprover } from "@/lib/document-queries";
import { roleLabel } from "@/lib/auth/roles";
import { getDocumentTracking } from "@/lib/download-tracking";

export const dynamic = "force-dynamic";

export default async function ApproverArchivePage() {
  const session = await requireRole([UserRole.APPROVER_1, UserRole.APPROVER_2, UserRole.APPROVER_3]);
  const data = await getDocumentsForApprover(session.userId, session.role, session.name);

  const archivedSource = data.myDocuments.filter((doc) => doc.status === DocumentStatus.ARCHIVED);
  const docTracking = await getDocumentTracking(session.userId, archivedSource.map((doc) => doc.id));

  const documents = data.myDocuments
    .filter((doc) => doc.status === DocumentStatus.ARCHIVED)
    .map((doc) => ({
      id: doc.id,
      documentNumber: doc.documentNumber,
      title: doc.title,
      status: doc.status,
      documentType: doc.documentType,
      mrType: doc.mrType,
      currentVersion: doc.currentVersion,
      currentApproverName: doc.currentApprover?.name || null,
      relatedComparisonId: doc.relatedComparison?.id || null,
      relatedComparisonDocumentNumber: doc.relatedComparison?.documentNumber || null,
      downloadedAt: docTracking.get(doc.id).downloadedAt,
      approvalDate: docTracking.get(doc.id).approvalDate,
      dateLabel: new Intl.DateTimeFormat("en-US", { dateStyle: "medium" }).format(doc.createdAt),
      lastUpdatedAt: doc.updatedAt,
      isRedirected: Boolean(doc.redirectedById),
    }));

  return (
    <DashboardShell role={session.role} userName={session.name} title="Archive" subtitle={`${roleLabel(session.role)} archived documents`}>
      <PageSummaryCards
        cards={[
          { label: "Archived", value: String(documents.length), tone: "bg-slate-200 text-slate-800 ring-1 ring-slate-300" },
          { label: "My Documents", value: String(data.myDocuments.length), tone: "bg-slate-900 text-white" },
          { label: "Pending", value: String(data.pendingDocuments.length), tone: "bg-yellow-50 text-yellow-900 ring-1 ring-yellow-200" },
        ]}
      />
      <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-200 px-5 py-4">
          <h3 className="text-base font-semibold text-slate-900">Archive</h3>
        </div>
        <DocumentListTable documents={documents} emptyMessage="No archived documents found." showBulkActions />
      </section>
    </DashboardShell>
  );
}
