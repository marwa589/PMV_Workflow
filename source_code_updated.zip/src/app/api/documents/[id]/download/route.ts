import { readFile } from "fs/promises";
import { DocumentStatus } from "@prisma/client";
import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth/session";
import { canAccessDocument } from "@/lib/auth/resource-access";
import { resolveStoredFilePath } from "@/lib/files";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }

  const { id: documentId } = await params;

  const canAccess = await canAccessDocument(session, documentId);
  if (!canAccess) {
    return NextResponse.json({ message: "Forbidden" }, { status: 403 });
  }

  const document = await prisma.document.findUnique({
    where: { id: documentId },
    select: {
      id: true,
      currentVersion: true,
      status: true,
    },
  });

  if (!document) {
    return NextResponse.json({ message: "Document not found." }, { status: 404 });
  }

  const versionParam = new URL(request.url).searchParams.get("version");
  const targetVersionNumber =
    versionParam !== null && !isNaN(Number(versionParam))
      ? Number(versionParam)
      : document.currentVersion;

  const version = await prisma.documentVersion.findUnique({
    where: {
      documentId_versionNumber: {
        documentId,
        versionNumber: targetVersionNumber,
      },
    },
    select: {
      filePath: true,
      originalName: true,
      mimeType: true,
    },
  });

  if (!version) {
    return NextResponse.json({ message: "Document version not found." }, { status: 404 });
  }

  try {
    const absolutePath = resolveStoredFilePath(version.filePath);
    const buffer = await readFile(absolutePath);

    const isInline = new URL(request.url).searchParams.get("inline") === "1";
    if (document.status === DocumentStatus.APPROVED && !isInline) {
      await prisma.documentDownload.upsert({
        where: { documentId_userId: { documentId, userId: session.userId } },
        create: { documentId, userId: session.userId },
        update: { downloadedAt: new Date() },
      });
    }

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "Content-Type": version.mimeType || "application/octet-stream",
        "Content-Disposition": `${isInline ? "inline" : "attachment"}; filename="${version.originalName}"`,
      },
    });
  } catch {
    return NextResponse.json({ message: "File not found on server." }, { status: 404 });
  }
}
