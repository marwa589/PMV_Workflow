import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { EmailEventType, ErrType, UserRole } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getErrAccess, canApproveErr } from "@/lib/err/permissions";
import {
  ERR_PDF_LIMITS,
  saveErrFile,
  saveErrPdf,
} from "@/lib/err/files";
import { deleteDocumentFiles } from "@/lib/files";
import {
  PdfValidationError,
  validatePdfUpload,
} from "@/lib/pdf-validation";
import { getNextErrStage, resolveErrApprover } from "@/lib/err/workflow";
import { projectStorageFolderFromFile } from "@/lib/err-storage";
import { getRequestOrigin } from "@/lib/request-origin";
import { runInBackground } from "@/lib/background";
import { isErrUploaderAccount } from "@/lib/err/uploader-access";
import { queueWorkflowEmailEvents } from "@/lib/workflow-email-batching";
import { MOHAMED_AVK_WORKFLOW_UPLOADER_EMAIL } from "@/lib/mohamed-document-workflow";
import { GLOBAL_ERR_UPLOADER_EMAILS } from "@/lib/err/uploader-access";
import { canRedirectDocuments } from "@/lib/document-redirect";

export const runtime = "nodejs";

class ErrActionError extends Error {}

type Decision = "APPROVE" | "REJECT" | "COMMENT" | "HOLD" | "REDIRECT";
type ApprovalRoute = "FINALIZE" | "ACTING_CEO" | "ACTING_CEO_THEN_CEO" | "CEO";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const access = await getErrAccess();

  if (!access) {
    return NextResponse.json(
      { message: "Please sign in." },
      { status: 401 },
    );
  }

  const { id } = await params;

  if (!(await canApproveErr(access, id))) {
    return NextResponse.json(
      { message: "You are not authorized to act on this ERR." },
      { status: 403 },
    );
  }

  const errForStorage = await prisma.err.findUnique({
  where: { id },
  select: {
    title: true,
    files: {
      where: { kind: "ERR_PDF" },
      orderBy: [
        { versionNumber: "desc" },
        { createdAt: "desc" },
      ],
      take: 1,
      select: { filePath: true, storageFolder: true },
    },
  },
});

  let formData: FormData;

  try {
    formData = await request.formData();
  } catch {
    return NextResponse.json(
      { message: "The review payload could not be read." },
      { status: 400 },
    );
  }

  const decision = String(formData.get("decision") || "")
    .trim()
    .toUpperCase() as Decision;
  const approvalRoute = String(formData.get("approvalRoute") || "")
    .trim()
    .toUpperCase() as ApprovalRoute | "";
  const comments = String(formData.get("comments") || "").trim();
  const fileValue = formData.get("file");
  const file = fileValue instanceof File ? fileValue : null;
  const quotationValue = formData.get("quotation");
  const quotationFile = quotationValue instanceof File && quotationValue.size > 0 ? quotationValue : null;
  const signatureCount = Number(formData.get("signatureCount") || 0);
  const redirectToUserId = String(formData.get("redirectToUserId") || "").trim();

  if (decision !== "APPROVE" && decision !== "REJECT" && decision !== "COMMENT" && decision !== "HOLD" && decision !== "REDIRECT") {
    return NextResponse.json(
      { message: "Decision must be APPROVE, REJECT, or COMMENT." },
      { status: 400 },
    );
  }

  if (decision === "REDIRECT" && quotationFile) {
    return NextResponse.json(
      { message: "Add the quotation when you approve, not when redirecting." },
      { status: 400 },
    );
  }

  if (decision === "REDIRECT" && !redirectToUserId) {
    return NextResponse.json(
      { message: "Choose the user to redirect this ERR to." },
      { status: 400 },
    );
  }

  if (decision === "APPROVE" && !file) {
    return NextResponse.json(
      { message: "A signed PDF is required to approve an ERR." },
      { status: 400 },
    );
  }

  if (quotationFile && !access.isPmvManager) {
    return NextResponse.json(
      { message: "Only the PMV Manager can add quotations during ERR review." },
      { status: 403 },
    );
  }

  if (quotationFile) {
    const extension = quotationFile.name.toLowerCase().split(".").pop() || "";
    if (!["pdf", "doc", "docx", "xls", "xlsx", "jpg", "jpeg", "png"].includes(extension)) {
      return NextResponse.json({ message: "Unsupported quotation file type." }, { status: 400 });
    }
    if (quotationFile.size > 20 * 1024 * 1024) {
      return NextResponse.json({ message: "The quotation must be 20 MB or smaller." }, { status: 400 });
    }
  }

  let validatedSignedPdf: Awaited<ReturnType<typeof validatePdfUpload>> | null = null;
  let savedSignedPdf: Awaited<ReturnType<typeof saveErrPdf>> | null = null;
  const savedPaths: string[] = [];

  if (decision === "APPROVE") {
    const signedFile = file;

    if (!signedFile) {
      return NextResponse.json(
        { message: "A signed PDF is required to approve an ERR." },
        { status: 400 },
      );
    }

    try {
      validatedSignedPdf = await validatePdfUpload(signedFile, ERR_PDF_LIMITS);
      savedSignedPdf = await saveErrPdf({
        errId: id,
        kind: "ERR_PDF",
        pdf: validatedSignedPdf,
        storageName: errForStorage?.title || id,
        storageFolder: errForStorage?.files[0]?.storageFolder || projectStorageFolderFromFile(errForStorage?.files[0]?.filePath),
        overwrite: true,
      });
      savedPaths.push(savedSignedPdf.filePath);
    } catch (error) {
      if (error instanceof PdfValidationError) {
        return NextResponse.json(
          { message: error.message },
          { status: 400 },
        );
      }

      console.error("ERR approval PDF preparation failed.", error);
      return NextResponse.json(
        { message: "Unable to prepare the signed ERR PDF." },
        { status: 500 },
      );
    }
  }

  let savedQuotation: Awaited<ReturnType<typeof saveErrFile>> | null = null;
  if (quotationFile) {
    try {
      savedQuotation = await saveErrFile({
        errId: id,
        kind: "QUOTATION",
        file: quotationFile,
        storageName: quotationFile.name,
        storageFolder: errForStorage?.files[0]?.storageFolder || projectStorageFolderFromFile(errForStorage?.files[0]?.filePath),
      });
      savedPaths.push(savedQuotation.filePath);
    } catch (error) {
      console.error("ERR quotation preparation failed.", error);
      return NextResponse.json({ message: "Unable to prepare the quotation." }, { status: 500 });
    }
  }

  try {
    const result = await prisma.$transaction(async (tx) => {
      const err = await tx.err.findUnique({
        where: { id },
        select: {
          id: true,
          documentNumber: true,
          title: true,
          type: true,
          status: true,
          currentStage: true,
          nextApprovalPath: true,
          currentApproverId: true,
          createdById: true,
          createdBy: { select: { location: true } },
          projectDirectorId: true,
          projectId: true,
          revisionNumber: true,
          lockVersion: true,
          redirectedById: true,
          files: {
            where: { kind: "ERR_PDF" },
            orderBy: [{ versionNumber: "desc" }, { createdAt: "desc" }],
            take: 1,
            select: {
              id: true,
              versionNumber: true,
            },
          },
        },
      });

      if (!err) {
        throw new ErrActionError("ERR not found.");
      }

      if (err.status !== "PENDING") {
        throw new ErrActionError("This ERR is no longer pending action.");
      }

      if (err.currentApproverId !== access.userId) {
        throw new ErrActionError("This ERR is not assigned to you.");
      }

      // Set while Marc has redirected the ERR to the current user.
      const isRedirectTarget = Boolean(err.redirectedById);

      if (isRedirectTarget && savedQuotation) {
        throw new ErrActionError("Quotations can only be added by the PMV Manager.");
      }

      if (isRedirectTarget && decision === "HOLD") {
        throw new ErrActionError("A redirected ERR cannot be put on hold. Approve, reject, or request a revision.");
      }

      if (decision === "REDIRECT") {
        if (isRedirectTarget || !canRedirectDocuments(access.email)) {
          throw new ErrActionError("Only the PMV Manager can redirect an ERR.");
        }
        if (err.currentStage !== "PMV_MANAGER") {
          throw new ErrActionError("An ERR can only be redirected at the PMV Manager stage.");
        }
        if (redirectToUserId === access.userId) {
          throw new ErrActionError("Choose another user to redirect this ERR to.");
        }

        const target = await tx.user.findUnique({
          where: { id: redirectToUserId },
          select: { id: true, name: true, role: true },
        });
        if (!target || target.role === UserRole.KSA_VIEWER) {
          throw new ErrActionError("The selected user cannot receive this ERR.");
        }

        const redirectedAt = new Date();
        await tx.err.update({
          where: { id: err.id },
          data: {
            currentApproverId: target.id,
            currentApproverAssignedAt: redirectedAt,
            redirectedById: access.userId,
            lockVersion: { increment: 1 },
          },
        });

        await tx.errApprovalHistory.create({
          data: {
            errId: err.id,
            performedById: access.userId,
            action: "REDIRECTED",
            stage: err.currentStage,
            comments: comments ? `Redirected to ${target.name}: ${comments}` : `Redirected to ${target.name}`,
            revisionNumber: err.revisionNumber,
            inputFileId: err.files[0]?.id ?? null,
          },
        });

        await tx.errNotification.create({
          data: {
            errId: err.id,
            recipientId: target.id,
            type: "APPROVAL_PENDING",
            eventKey: `err:${err.id}:redirect:${randomUUID()}`,
            title: "ERR redirected to you",
            message: `${err.documentNumber}: ${err.title}`,
            emailEnabled: false,
          },
        });

        return { status: "PENDING", message: `ERR redirected to ${target.name}.` };
      }

      if (savedQuotation && err.currentStage !== "PMV_MANAGER") {
        throw new ErrActionError("Quotations can only be added during PMV Manager review.");
      }

      if (savedQuotation) {
        const quotationCount = await tx.errFile.count({
          where: { errId: err.id, kind: "QUOTATION" },
        });
        await tx.errFile.create({
          data: {
            errId: err.id,
            kind: "QUOTATION",
            versionNumber: quotationCount + 1,
            revisionNumber: err.revisionNumber,
            filePath: savedQuotation.filePath,
            storageFolder: savedQuotation.storageFolder,
            originalName: savedQuotation.originalName,
            mimeType: savedQuotation.mimeType,
            fileSize: savedQuotation.fileSize,
            uploadedById: access.userId,
          },
        });
      }

      const latestErrPdf = err.files[0] ?? null;
      const nextVersionNumber = (latestErrPdf?.versionNumber ?? 0) + 1;
      const now = new Date();

      if (decision === "HOLD") {
        await tx.err.update({
          where: { id: err.id },
          data: {
            status: "ON_HOLD",
            currentApproverAssignedAt: now,
            lockVersion: { increment: 1 },
          },
        });

        await tx.errApprovalHistory.create({
          data: {
            errId: err.id,
            performedById: access.userId,
            action: "PUT_ON_HOLD",
            stage: err.currentStage,
            comments: comments || null,
            revisionNumber: err.revisionNumber,
            inputFileId: latestErrPdf?.id ?? null,
          },
        });

        await tx.errNotification.create({
          data: {
            errId: err.id,
            recipientId: err.createdById,
            type: "ON_HOLD",
            eventKey: `err:${err.id}:on-hold:${randomUUID()}`,
            title: "ERR placed on hold",
            message: `${err.documentNumber}: ${err.title}`,
            emailEnabled: false,
          },
        });

        return { status: "ON_HOLD", message: "ERR placed on hold." };
      }

      if (decision === "APPROVE") {
        if (!savedSignedPdf) {
          throw new ErrActionError("A signed PDF is required to approve this ERR.");
        }

        const pendingRoute = err.currentStage === "PMV_MANAGER"
          ? approvalRoute || "FINALIZE"
          : err.currentStage === "ACTING_CEO"
            ? err.nextApprovalPath || "FINALIZE"
            : "FINALIZE";

        const selectedRoute: ApprovalRoute = pendingRoute === "ACTING_CEO_THEN_CEO"
          ? "ACTING_CEO_THEN_CEO"
          : pendingRoute === "ACTING_CEO"
            ? "ACTING_CEO"
            : pendingRoute === "CEO"
              ? "CEO"
              : "FINALIZE";

        const outputFile = latestErrPdf
          ? await tx.errFile.update({
              where: { id: latestErrPdf.id },
              data: {
                versionNumber: nextVersionNumber,
                revisionNumber: err.revisionNumber,
                filePath: savedSignedPdf.filePath,
                  storageFolder: savedSignedPdf.storageFolder,
                originalName: savedSignedPdf.originalName,
                mimeType: savedSignedPdf.mimeType,
                fileSize: savedSignedPdf.fileSize,
                uploadedById: access.userId,
              },
            })
          : await tx.errFile.create({
              data: {
            errId: err.id,
            kind: "ERR_PDF",
            versionNumber: nextVersionNumber,
            revisionNumber: err.revisionNumber,
            filePath: savedSignedPdf.filePath,
            storageFolder: savedSignedPdf.storageFolder,
            originalName: savedSignedPdf.originalName,
            mimeType: savedSignedPdf.mimeType,
            fileSize: savedSignedPdf.fileSize,
            uploadedById: access.userId,
              },
            });

        // Redirected ERR approved: it goes back to Marc at his stage for his own decision.
        if (isRedirectTarget && err.redirectedById) {
          await tx.err.update({
            where: { id: err.id },
            data: {
              currentApproverId: err.redirectedById,
              currentApproverAssignedAt: now,
              redirectedById: null,
              lockVersion: { increment: 1 },
            },
          });

          await tx.errApprovalHistory.create({
            data: {
              errId: err.id,
              performedById: access.userId,
              action: "REDIRECT_APPROVED",
              stage: err.currentStage,
              comments: comments || null,
              revisionNumber: err.revisionNumber,
              inputFileId: latestErrPdf?.id ?? null,
              outputFileId: outputFile.id,
            },
          });

          await tx.errNotification.create({
            data: {
              errId: err.id,
              recipientId: err.redirectedById,
              type: "APPROVAL_PENDING",
              eventKey: `err:${err.id}:redirect-approved:${randomUUID()}`,
              title: "Redirected ERR approved and returned to you",
              message: `${err.documentNumber}: ${err.title}`,
              emailEnabled: false,
            },
          });

          return { status: "PENDING", message: "ERR approved and sent back to the PMV Manager." };
        }

        const nextStage = err.currentStage === "PMV_MANAGER"
          ? selectedRoute === "ACTING_CEO" || selectedRoute === "ACTING_CEO_THEN_CEO"
            ? "ACTING_CEO"
            : selectedRoute === "CEO"
              ? "CEO"
              : null
          : err.currentStage === "ACTING_CEO"
            ? selectedRoute === "ACTING_CEO_THEN_CEO" ? "CEO" : null
            : err.currentStage === "CEO"
              ? null
              : getNextErrStage(err.type, err.currentStage);

        let nextApproverId: string | null = null;
        let nextStatus: "PENDING" | "APPROVED" = "APPROVED";
        let nextStageValue = err.currentStage;
        let approvedAt: Date | null = null;

        if (nextStage) {
          nextApproverId = await resolveErrApprover(
            tx,
            nextStage,
            err.projectDirectorId,
            err.projectId,
          );
          nextStageValue = nextStage;
          nextStatus = "PENDING";
        } else {
          approvedAt = now;
          nextStageValue = err.currentStage;
        }

        await tx.err.update({
          where: { id: err.id },
          data: {
            status: nextStatus,
            currentStage: nextStageValue,
            nextApprovalPath: err.currentStage === "PMV_MANAGER"
              ? selectedRoute === "ACTING_CEO" || selectedRoute === "ACTING_CEO_THEN_CEO" || selectedRoute === "CEO"
                ? selectedRoute
                : null
              : err.currentStage === "ACTING_CEO"
                ? null
                : err.nextApprovalPath,
            currentApproverId: nextApproverId,
            currentApproverAssignedAt: nextApproverId ? now : null,
            approvedAt,
            lockVersion: { increment: 1 },
          },
        });

        await tx.errApprovalHistory.create({
          data: {
            errId: err.id,
            performedById: access.userId,
            action: err.currentStage === "PROJECT_DIRECTOR"
              ? "APPROVED"
              : err.currentStage === "ACTING_CEO" && selectedRoute === "ACTING_CEO_THEN_CEO"
                ? "ESCALATED_TO_CEO"
                : selectedRoute === "CEO"
                  ? "ESCALATED_TO_CEO"
                  : selectedRoute === "ACTING_CEO" || selectedRoute === "ACTING_CEO_THEN_CEO"
                    ? "ESCALATED_TO_ACTING_CEO"
                    : "FINALIZED_APPROVAL",
            stage: err.currentStage,
            comments: comments || null,
            revisionNumber: err.revisionNumber,
            inputFileId: latestErrPdf?.id ?? null,
            outputFileId: outputFile.id,
          },
        });

        if (nextApproverId) {
          await tx.errNotification.create({
            data: {
              errId: err.id,
              recipientId: nextApproverId,
              type: "APPROVAL_PENDING",
              eventKey: `err:${err.id}:approval:${randomUUID()}`,
              title: "ERR awaiting your approval",
              message: `${err.documentNumber}: ${err.title}`,
              emailEnabled: false,
            },
          });
        } else {
          await tx.errNotification.create({
            data: {
              errId: err.id,
              recipientId: err.createdById,
              type: "APPROVED",
              eventKey: `err:${err.id}:approved:${randomUUID()}`,
              title: "ERR approved",
              message: `${err.documentNumber}: ${err.title}`,
              emailEnabled: false,
            },
          });

          if (err.createdBy.location === "AVK" && err.createdById !== access.userId) {
            const avkUploader = await tx.user.findUnique({
              where: { email: MOHAMED_AVK_WORKFLOW_UPLOADER_EMAIL },
              select: { id: true },
            });
            if (avkUploader && avkUploader.id !== err.createdById) {
              await tx.errNotification.create({
                data: {
                  errId: err.id,
                  recipientId: avkUploader.id,
                  type: "APPROVED",
                  eventKey: `err:${err.id}:approved:avk:${randomUUID()}`,
                  title: "AVK ERR approved",
                  message: `${err.documentNumber}: ${err.title}`,
                  emailEnabled: false,
                },
              });
            }
          }
        }

        return {
          status: nextStatus,
          message: nextStage
            ? "ERR advanced to the next approval stage."
            : "ERR finalized and approved.",
        };
      }

      if (decision === "REJECT") {
        await tx.err.update({
          where: { id: err.id },
          data: {
            status: "REJECTED",
            currentApproverId: null,
            currentApproverAssignedAt: null,
            redirectedById: null,
            lockVersion: { increment: 1 },
          },
        });

        await tx.errApprovalHistory.create({
          data: {
            errId: err.id,
            performedById: access.userId,
            action: "REJECTED",
            stage: err.currentStage,
            comments: comments || null,
            revisionNumber: err.revisionNumber,
            inputFileId: latestErrPdf?.id ?? null,
          },
        });

        await tx.errNotification.create({
          data: {
            errId: err.id,
            recipientId: err.createdById,
            type: "REJECTED",
            eventKey: `err:${err.id}:rejected:${randomUUID()}`,
            title: "ERR rejected",
            message: `${err.documentNumber}: ${err.title}`,
            emailEnabled: false,
          },
        });

        return {
          status: "REJECTED",
          message: "ERR rejected.",
        };
      }

      await tx.err.update({
        where: { id: err.id },
        data: {
          status: "REVISION_REQUIRED",
          currentApproverId: err.createdById,
          currentApproverAssignedAt: now,
          redirectedById: null,
          lockVersion: { increment: 1 },
        },
      });

      await tx.errApprovalHistory.create({
        data: {
          errId: err.id,
          performedById: access.userId,
          action: "REQUESTED_REVISION",
          stage: err.currentStage,
          comments: comments || null,
          revisionNumber: err.revisionNumber,
          inputFileId: latestErrPdf?.id ?? null,
        },
      });

      await tx.errNotification.create({
        data: {
          errId: err.id,
          recipientId: err.createdById,
          type: "REVISION_REQUIRED",
          eventKey: `err:${err.id}:revision:${randomUUID()}`,
          title: "ERR requires revision",
          message: `${err.documentNumber}: ${err.title}`,
          emailEnabled: false,
        },
      });

      return {
        status: "REVISION_REQUIRED",
        message: "ERR returned for revision.",
      };
    });

    runInBackground(async () => {
      try {
        await prisma.emailNotificationEvent.updateMany({
          where: {
            recipientId: access.userId,
            documentId: id,
            type: EmailEventType.ERR_WORKFLOW_UPDATE,
            emailSent: false,
            claimedAt: null,
          },
          data: { emailSent: true, claimedAt: null },
        });

        const errForEmail = await prisma.err.findUnique({
          where: { id },
          select: {
            documentNumber: true,
            title: true,
            createdById: true,
            createdBy: { select: { location: true } },
            currentApproverId: true,
            type: true,
          },
        });
        if (!errForEmail) return;

        const globalErrUploaders = await prisma.user.findMany({
          where: { email: { in: [...GLOBAL_ERR_UPLOADER_EMAILS] } },
          select: { id: true },
        });
        const globalNotificationType = result.status === "APPROVED"
          ? "APPROVED" as const
          : result.status === "REJECTED"
            ? "REJECTED" as const
            : result.status === "REVISION_REQUIRED"
              ? "REVISION_REQUIRED" as const
              : result.status === "ON_HOLD"
                ? "ON_HOLD" as const
                : "APPROVAL_PENDING" as const;
        const globalNotificationTitle = result.status === "APPROVED"
          ? "ERR approved"
          : result.status === "REJECTED"
            ? "ERR rejected"
            : result.status === "REVISION_REQUIRED"
              ? "ERR requires revision"
              : result.status === "ON_HOLD"
                ? "ERR placed on hold"
                : "ERR approval updated";
        const globalNotificationRecipients = globalErrUploaders.filter((uploader) =>
          uploader.id !== errForEmail.createdById
          && !(result.status === "PENDING" && uploader.id === errForEmail.currentApproverId),
        );
        if (globalNotificationRecipients.length > 0) {
          await prisma.errNotification.createMany({
            data: globalNotificationRecipients.map((uploader) => ({
              errId: id,
              recipientId: uploader.id,
              type: globalNotificationType,
              eventKey: `err:${id}:global:${result.status}:${randomUUID()}`,
              title: globalNotificationTitle,
              message: `${errForEmail.documentNumber}: ${errForEmail.title}`,
              emailEnabled: false,
            })),
            skipDuplicates: true,
          });
        }

        const uploaderUsers = await prisma.user.findMany({
          where: {
            OR: [
              { id: errForEmail.createdById },
              { errAccess: { some: { role: "UPLOADER", isActive: true } } },
              { role: "ERR_USER" },
              ...(result.status === "APPROVED" && errForEmail.createdBy.location === "AVK"
                ? [{ email: MOHAMED_AVK_WORKFLOW_UPLOADER_EMAIL }]
                : []),
              { name: { contains: "kamel", mode: "insensitive" } },
            ],
          },
          select: {
            name: true,
            email: true,
            id: true,
            role: true,
            location: true,
            errAccess: {
              where: { role: "UPLOADER", isActive: true },
              select: { id: true },
            },
          },
        });
        const eligibleUploaders = uploaderUsers.filter((user) =>
          user.email && (
            user.id === errForEmail.createdById
            || user.errAccess.length > 0
            || isErrUploaderAccount(user.name, user.role)
            || (user.name.trim().toLowerCase().includes("kamel") && (result.status === "APPROVED" || result.status === "REJECTED"))
          ),
        );
        const finalApprovalOnlyRecipientIds = new Set(
          eligibleUploaders
            .filter((user) => {
              const normalizedName = user.name.trim().toLowerCase();
              return normalizedName.includes("kamel");
            })
            .map((user) => user.id),
        );
        const locationRecipients = result.status === "PENDING"
          ? []
          : eligibleUploaders.filter((user) =>
              (errForEmail.createdBy.location === "KUWAIT"
                ? user.location === "KUWAIT"
                : user.location !== "KUWAIT")
              && (result.status !== "REJECTED"
                || user.email.trim().toLowerCase() !== "mohammad.mehieddine@ahmadiah.com"
                || user.id === errForEmail.createdById),
            );
        const globalRecipients = eligibleUploaders.filter((user) =>
          isErrUploaderAccount(user.name, user.role)
            || ((result.status === "APPROVED" || result.status === "REJECTED") && user.name.trim().toLowerCase().includes("kamel")),
        );
        const nextApprover = result.status === "PENDING" && errForEmail.currentApproverId
          ? [{ id: errForEmail.currentApproverId }]
          : [];
        const workshopManagers = result.status === "APPROVED" && errForEmail.type === ErrType.RENTAL_ACTC
          ? await prisma.user.findMany({
              where: { role: UserRole.APPROVER_2 },
              select: { id: true },
            })
          : [];
        // Tayyab is copied on approved KSA (non-Kuwait) ERRs only.
        const ksaApprovedExtraRecipients = result.status === "APPROVED" && errForEmail.createdBy.location !== "KUWAIT"
          ? await prisma.user.findMany({
              where: { email: { equals: "mohamad.tayyab@ahmadiah.com", mode: "insensitive" } },
              select: { id: true, email: true },
            })
          : [];
        const recipients = Array.from(
          new Map(
            [...eligibleUploaders.filter((user) => user.id === errForEmail.createdById), ...globalRecipients, ...locationRecipients, ...nextApprover, ...workshopManagers, ...ksaApprovedExtraRecipients]
              .filter((recipient) => "email" in recipient ? Boolean(recipient.email) : true)
              .filter((recipient) => result.status === "APPROVED" || result.status === "REJECTED" || !finalApprovalOnlyRecipientIds.has(recipient.id))
              .map((recipient) => [recipient.id, recipient]),
          ).values(),
        );

        await queueWorkflowEmailEvents(recipients.map((recipient) => ({
          recipientId: recipient.id,
          type: EmailEventType.ERR_WORKFLOW_UPDATE,
          documentId: id,
        })));
      } catch (error) {
        console.error("ERR action email notifications could not be queued.", error);
      }
    });

    return NextResponse.json(
      { message: result.message, status: result.status },
      { status: 200 },
    );
  } catch (error) {
    if (savedPaths.length > 0) {
      const previousFilePath = errForStorage?.files[0]?.filePath;
      const pathsToDelete = savedPaths.filter((filePath) => filePath !== previousFilePath);
      if (pathsToDelete.length > 0) {
        await deleteDocumentFiles({ filePaths: pathsToDelete });
      }
    }

    if (error instanceof ErrActionError) {
      return NextResponse.json(
        { message: error.message },
        { status: 400 },
      );
    }

    console.error("ERR action could not be processed.", error);

    return NextResponse.json(
      { message: "Unable to process this ERR action." },
      { status: 500 },
    );
  }
}
